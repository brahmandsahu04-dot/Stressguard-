import { BAND, formatDate } from './Common.jsx';

// Dependency-free SVG line chart of percent-of-maximum scores. The shaded zones match the bands.
export default function TrendChart({ points }) {
  const W = 640, H = 240, L = 44, R = 16, T = 14, B = 34;
  const iw = W - L - R, ih = H - T - B;
  const y = (pct) => T + ih - (pct / 100) * ih;

  if (!points.length) return null;
  const times = points.map((p) => new Date(p.completedAt).getTime());
  const t0 = Math.min(...times), t1 = Math.max(...times);
  const x = (t) => (t1 === t0 ? L + iw / 2 : L + ((t - t0) / (t1 - t0)) * iw);
  const path = points.map((p, i) => `${i ? 'L' : 'M'}${x(times[i]).toFixed(1)},${y(p.percent).toFixed(1)}`).join(' ');
  const summary = `Line chart of ${points.length} check-in${points.length > 1 ? 's' : ''}. Latest score ${points[points.length - 1].percent} percent of maximum.`;

  return (
    <figure className="chart">
      <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label={summary}>
        <rect x={L} y={y(33)} width={iw} height={y(0) - y(33)} className="zone low" />
        <rect x={L} y={y(66)} width={iw} height={y(33) - y(66)} className="zone mod" />
        <rect x={L} y={y(100)} width={iw} height={y(66) - y(100)} className="zone high" />
        {[0, 33, 66, 100].map((v) => (
          <g key={v}>
            <line x1={L} x2={W - R} y1={y(v)} y2={y(v)} className="grid-line" />
            <text x={L - 8} y={y(v) + 4} textAnchor="end" className="axis">{v}%</text>
          </g>
        ))}
        {points.length > 1 && <path d={path} className="line" fill="none" />}
        {points.map((p, i) => (
          <circle key={p.id} cx={x(times[i])} cy={y(p.percent)} r="5" className={`dot ${BAND[p.band].cls}`}>
            <title>{`${formatDate(p.completedAt)}: ${p.totalScore}/${p.maxScore} (${BAND[p.band].label})`}</title>
          </circle>
        ))}
        <text x={L} y={H - 10} className="axis">{formatDate(points[0].completedAt)}</text>
        {points.length > 1 && (
          <text x={W - R} y={H - 10} textAnchor="end" className="axis">{formatDate(points[points.length - 1].completedAt)}</text>
        )}
      </svg>
      <figcaption className="muted small">Score as a percentage of the maximum. Lower is better.</figcaption>
    </figure>
  );
}
