import { Link } from 'react-router-dom';

export const BAND = {
  LOW: { label: 'Lower', cls: 'low', icon: '●' },
  MODERATE: { label: 'Moderate', cls: 'mod', icon: '◆' },
  HIGH: { label: 'Higher', cls: 'high', icon: '▲' },
};

export const CATEGORY_LABEL = {
  STRESS: 'Stress', MOOD: 'Mood', SLEEP: 'Sleep', WORKLOAD: 'Workload',
  CONCENTRATION: 'Concentration', SUPPORT: 'Support', GENERAL: 'General',
};

export function BandBadge({ band }) {
  const b = BAND[band] || BAND.LOW;
  return <span className={`badge ${b.cls}`}><span aria-hidden="true">{b.icon}</span> {b.label}</span>;
}

export function formatDate(iso, withTime = false) {
  if (!iso) return '';
  const d = new Date(iso);
  const opts = withTime
    ? { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }
    : { day: 'numeric', month: 'short', year: 'numeric' };
  return d.toLocaleString('en-IN', opts);
}

export function Loading({ text = 'Loading…' }) {
  return <p className="muted" role="status">{text}</p>;
}

export function ErrorNote({ error }) {
  if (!error) return null;
  return <div className="alert alert-error" role="alert">{error.message || String(error)}</div>;
}

export function Disclaimer() {
  return (
    <p className="disclaimer">
      This score is a self-reported wellness indicator. It is not a medical diagnosis and does not replace advice
      from a qualified professional.
    </p>
  );
}

export function EmptyState({ title, children }) {
  return (
    <div className="empty">
      <h3>{title}</h3>
      <p className="muted">{children}</p>
      <Link className="btn" to="/checkin">Start a check-in</Link>
    </div>
  );
}

export function SupportContacts({ contacts, urgent }) {
  if (!contacts?.length) return null;
  return (
    <section className={`card support ${urgent ? 'urgent' : ''}`} aria-labelledby="support-h">
      <h2 id="support-h">{urgent ? 'You are not alone — please reach out now' : 'Support is available'}</h2>
      <p>
        {urgent
          ? 'You told us you may be having thoughts of harming yourself or feeling unsafe. Please contact someone right away. These services are staffed by people, not by this website — StressGuard is not monitored by a clinician.'
          : 'Talking to someone can help. These free services are run by people and are not monitored by StressGuard.'}
      </p>
      <ul className="contacts">
        {contacts.map((c) => (
          <li key={c.name}>
            <strong>{c.name}</strong>
            <a className="phone" href={`tel:${c.phone.replace(/[^0-9+]/g, '')}`}>{c.phone}</a>
            <span className="muted small">{c.note}</span>
          </li>
        ))}
      </ul>
    </section>
  );
}

export function ResultView({ result }) {
  const cats = result.categoryScores || [];
  return (
    <>
      {result.urgent && <SupportContacts contacts={result.supportContacts} urgent />}

      <section className="card result-head" aria-labelledby="score-h">
        <div>
          <p className="eyebrow">Check-in on {formatDate(result.completedAt, true)}</p>
          <h1 id="score-h">Your stress indicator</h1>
          <p className="big-score">
            {result.totalScore}<span className="muted"> / {result.maxScore}</span> <BandBadge band={result.band} />
          </p>
          <p>{result.guidance}</p>
        </div>
        <div className="meter" role="img" aria-label={`${result.percent} percent of the maximum score`}>
          <div className="meter-track">
            <div className={`meter-fill ${BAND[result.band].cls}`} style={{ width: `${result.percent}%` }} />
          </div>
          <div className="meter-scale"><span>Lower</span><span>Moderate</span><span>Higher</span></div>
        </div>
        <Disclaimer />
      </section>

      <section className="card" aria-labelledby="cat-h">
        <h2 id="cat-h">What contributed</h2>
        <p className="muted small">Each bar shows how often you reported this area in the last 7 days.</p>
        <ul className="cat-list">
          {cats.map((c) => {
            const pct = Math.round((c.score / c.maxScore) * 100);
            return (
              <li key={c.category}>
                <span className="cat-name">{CATEGORY_LABEL[c.category] || c.category}</span>
                <span className="bar" aria-hidden="true"><span style={{ width: `${pct}%` }} /></span>
                <span className="cat-val">{c.score}/{c.maxScore}</span>
              </li>
            );
          })}
        </ul>
      </section>

      {!result.urgent && <SupportContacts contacts={result.supportContacts} />}

      <section aria-labelledby="rec-h">
        <h2 id="rec-h">Suggestions for you</h2>
        <div className="grid">
          {result.recommendations.map((r) => (
            <article className="card tip" key={r.id}>
              <span className="chip">{CATEGORY_LABEL[r.category] || r.category}</span>
              <h3>{r.title}</h3>
              <p>{r.content}</p>
            </article>
          ))}
        </div>
      </section>
    </>
  );
}
