import { useEffect, useState } from 'react';

// A simple 4-4-4-4 "box breathing" guide. Motion is removed for people who prefer reduced motion.
const PHASES = ['Breathe in', 'Hold', 'Breathe out', 'Hold'];

export default function BreathingGuide() {
  const [running, setRunning] = useState(false);
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    if (!running) return undefined;
    const id = setInterval(() => setPhase((p) => (p + 1) % 4), 4000);
    return () => clearInterval(id);
  }, [running]);

  const expanded = running && (phase === 0 || phase === 1);
  return (
    <section className="card breathing" aria-labelledby="breath-h">
      <h2 id="breath-h">Try a 1-minute breathing break</h2>
      <p className="muted">Follow the circle: four seconds in, hold, four seconds out, hold.</p>
      <div className={`orb ${expanded ? 'big' : ''}`} aria-hidden="true" />
      <p className="phase" role="status" aria-live="polite">{running ? PHASES[phase] : 'Ready when you are'}</p>
      <button className="btn" onClick={() => { setPhase(0); setRunning((r) => !r); }}>
        {running ? 'Stop' : 'Start'}
      </button>
    </section>
  );
}
