// Thin wrapper around fetch for the StressGuard REST API.
const TOKEN_KEY = 'sg_token';
const USER_KEY = 'sg_user';

function safe(fn, fallback = null) {
  try { return fn(); } catch { return fallback; }
}

export const session = {
  token: () => safe(() => sessionStorage.getItem(TOKEN_KEY)),
  user: () => safe(() => JSON.parse(sessionStorage.getItem(USER_KEY))),
  save(token, user) {
    safe(() => { sessionStorage.setItem(TOKEN_KEY, token); sessionStorage.setItem(USER_KEY, JSON.stringify(user)); });
  },
  clear() {
    safe(() => { sessionStorage.removeItem(TOKEN_KEY); sessionStorage.removeItem(USER_KEY); });
  },
};

export class ApiError extends Error {
  constructor(status, body) {
    super(body?.message || 'Something went wrong. Please try again.');
    this.status = status;
    this.code = body?.code;
    this.fields = body?.fields || {};
  }
}

async function request(method, path, body, { raw = false } = {}) {
  const headers = {};
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  const token = session.token();
  if (token) headers.Authorization = `Bearer ${token}`;

  let res;
  try {
    res = await fetch(`/api${path}`, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined });
  } catch {
    throw new ApiError(0, { message: 'Cannot reach the server. Check your connection and try again.' });
  }
  if (res.status === 204) return null;
  if (raw && res.ok) return res.blob();

  let data = null;
  try { data = await res.json(); } catch { /* empty body */ }
  if (!res.ok) {
    // An expired or invalid token on a protected call logs the user out.
    if (res.status === 401 && token && !path.startsWith('/auth/')) {
      session.clear();
      window.dispatchEvent(new Event('sg:logout'));
    }
    throw new ApiError(res.status, data);
  }
  return data;
}

export const api = {
  register: (b) => request('POST', '/auth/register', b),
  login: (b) => request('POST', '/auth/login', b),
  forgot: (email) => request('POST', '/auth/forgot-password', { email }),
  reset: (token, newPassword) => request('POST', '/auth/reset-password', { token, newPassword }),

  questions: () => request('GET', '/questions'),
  submitAssessment: (b) => request('POST', '/assessments', b),
  history: () => request('GET', '/assessments/me'),
  trends: (days) => request('GET', `/assessments/trends?days=${days}`),
  assessment: (id) => request('GET', `/assessments/${id}`),
  resources: () => request('GET', '/resources'),

  consents: () => request('GET', '/consents'),
  setConsent: (purpose, granted) => request('PUT', '/consents', { purpose, granted }),
  reminder: () => request('GET', '/reminders'),
  setReminder: (enabled) => request('PUT', '/reminders', { enabled }),
  exportData: () => request('GET', '/privacy/export', undefined, { raw: true }),
  deleteAccount: (password) => request('DELETE', '/privacy/account', { password }),

  adminStats: () => request('GET', '/admin/stats'),
  adminQuestions: () => request('GET', '/admin/questions'),
  adminCreateQuestion: (b) => request('POST', '/admin/questions', b),
  adminUpdateQuestion: (id, b) => request('PUT', `/admin/questions/${id}`, b),
};
