import { useEffect, useState } from 'react';
import { api } from '../api.js';
import { useAuth } from '../auth.jsx';
import { ErrorNote, Loading, formatDate } from '../components/Common.jsx';

export default function Privacy() {
  const { logout } = useAuth();
  const [consent, setConsent] = useState(null);
  const [reminder, setReminder] = useState(null);
  const [error, setError] = useState(null);
  const [notice, setNotice] = useState(null);
  const [password, setPassword] = useState('');

  useEffect(() => {
    Promise.all([api.consents(), api.reminder()])
      .then(([c, r]) => { setConsent(c.find((x) => x.purpose === 'ASSESSMENT_STORAGE')); setReminder(r); })
      .catch(setError);
  }, []);

  async function run(fn, ok) {
    setError(null); setNotice(null);
    try { await fn(); if (ok) setNotice(ok); } catch (e) { setError(e); }
  }

  const toggleConsent = () => run(async () => {
    const list = await api.setConsent('ASSESSMENT_STORAGE', !consent.active);
    setConsent(list.find((x) => x.purpose === 'ASSESSMENT_STORAGE'));
  }, consent?.active ? 'Consent withdrawn. New check-ins cannot be saved until you agree again.' : 'Consent saved.');

  const toggleReminder = () => run(async () => setReminder(await api.setReminder(!reminder.enabled)));

  const exportData = () => run(async () => {
    const blob = await api.exportData();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'stressguard-data.json';
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
  }, 'Your data export has been downloaded.');

  const deleteAccount = (e) => {
    e.preventDefault();
    if (!window.confirm('Permanently delete your account and all your check-ins? This cannot be undone.')) return;
    run(async () => { await api.deleteAccount(password); logout(); });
  };

  if (!consent || !reminder) return error ? <ErrorNote error={error} /> : <Loading />;

  return (
    <>
      <h1>Privacy &amp; consent</h1>
      <ErrorNote error={error} />
      {notice && <div className="alert alert-ok" role="status">{notice}</div>}

      <section className="card" aria-labelledby="what-h">
        <h2 id="what-h">What StressGuard stores</h2>
        <ul>
          <li><strong>Account:</strong> your name, e-mail and a securely hashed password.</li>
          <li><strong>Check-ins:</strong> your answers, score and date — only if you consent below.</li>
          <li><strong>Never collected:</strong> camera, microphone, sensors, location or device data.</li>
          <li><strong>Who can see it:</strong> only you. Administrators see anonymous totals, never your answers.</li>
          <li><strong>Retention:</strong> kept until you delete your account; deletion is immediate and permanent.</li>
        </ul>
      </section>

      <section className="card" aria-labelledby="cons-h">
        <div className="row-between">
          <div>
            <h2 id="cons-h">Store my check-in answers</h2>
            <p className="muted small">
              {consent.active
                ? `Consent given on ${formatDate(consent.grantedAt, true)} (policy ${consent.version}).`
                : consent.withdrawnAt ? `Withdrawn on ${formatDate(consent.withdrawnAt, true)}.` : 'Not given yet.'}
            </p>
          </div>
          <button className={`switch ${consent.active ? 'on' : ''}`} role="switch" aria-checked={consent.active}
                  aria-labelledby="cons-h" onClick={toggleConsent}><span /></button>
        </div>
      </section>

      <section className="card" aria-labelledby="rem-h">
        <div className="row-between">
          <div>
            <h2 id="rem-h">Weekly check-in reminder</h2>
            <p className="muted small">
              Off by default. When on, a reminder appears on your dashboard once a week
              {reminder.enabled && reminder.nextDue ? ` (next: ${formatDate(reminder.nextDue)})` : ''}.
            </p>
          </div>
          <button className={`switch ${reminder.enabled ? 'on' : ''}`} role="switch" aria-checked={reminder.enabled}
                  aria-labelledby="rem-h" onClick={toggleReminder}><span /></button>
        </div>
      </section>

      <section className="card" aria-labelledby="exp-h">
        <h2 id="exp-h">Export my data</h2>
        <p className="muted small">Download everything we hold about you as a JSON file.</p>
        <button className="btn btn-ghost" onClick={exportData}>Download my data</button>
      </section>

      <section className="card danger" aria-labelledby="del-h">
        <h2 id="del-h">Delete my account</h2>
        <p className="muted small">Removes your account, consents, reminders and every check-in permanently.</p>
        <form onSubmit={deleteAccount}>
          <label className="field">Confirm with your password
            <input type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </label>
          <button className="btn btn-danger" disabled={!password}>Delete everything</button>
        </form>
      </section>
    </>
  );
}
