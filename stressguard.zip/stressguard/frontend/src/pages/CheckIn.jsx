import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import { ErrorNote, Loading } from '../components/Common.jsx';

// Single question, exactly in the spirit of section 5.4 of the report.
function StressQuestion({ question, choices, value, onChange }) {
  return (
    <fieldset className="question">
      <legend>{question.text}</legend>
      <div className="choices">
        {choices.map((choice, index) => (
          <label key={choice} className={`choice ${value === index ? 'selected' : ''}`}>
            <input type="radio" name={question.id} value={index} checked={value === index}
                   onChange={() => onChange(index)} required />
            <span>{choice}</span>
          </label>
        ))}
      </div>
    </fieldset>
  );
}

export default function CheckIn() {
  const navigate = useNavigate();
  const [meta, setMeta] = useState(null);
  const [consent, setConsent] = useState(null);
  const [answers, setAnswers] = useState([]);
  const [step, setStep] = useState(0);
  const [safety, setSafety] = useState(null); // null = unanswered, true/false
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    Promise.all([api.questions(), api.consents()])
      .then(([q, c]) => {
        setMeta(q);
        setAnswers(Array(q.questions.length).fill(null));
        setConsent(c.find((x) => x.purpose === 'ASSESSMENT_STORAGE')?.active ?? false);
      })
      .catch(setError);
  }, []);

  if (error && !meta) return <ErrorNote error={error} />;
  if (!meta || consent === null) return <Loading />;

  const n = meta.questions.length;
  const safetyStep = n;
  const reviewStep = n + 1;
  const total = n + 2;

  async function grant() {
    setError(null);
    try {
      await api.setConsent('ASSESSMENT_STORAGE', true);
      setConsent(true);
    } catch (e) { setError(e); }
  }

  async function submit() {
    setBusy(true);
    setError(null);
    try {
      const result = await api.submitAssessment({
        questionnaireVersion: meta.version, answers, consentConfirmed: true, safetyConcern: safety === true,
      });
      navigate(`/result/${result.id}`, { state: { result } });
    } catch (e) {
      setError(e);
      setBusy(false);
    }
  }

  if (!consent) {
    return (
      <section className="card narrow" aria-labelledby="consent-h">
        <h1 id="consent-h">Before you start</h1>
        <p>To show you history and trends, StressGuard needs your permission to store your answers.</p>
        <ul>
          <li>We store your answers, your score and the date of each check-in.</li>
          <li>Only you can see them. Administrators see anonymous totals only.</li>
          <li>You can withdraw consent, export or delete your data at any time in <Link to="/privacy">Privacy settings</Link>.</li>
        </ul>
        <ErrorNote error={error} />
        <button className="btn" onClick={grant}>I agree — continue</button>
      </section>
    );
  }

  const stepAnswered = step < n ? answers[step] !== null : step === safetyStep ? safety !== null : true;
  const next = () => setStep((s) => Math.min(s + 1, reviewStep));
  const back = () => setStep((s) => Math.max(s - 1, 0));

  return (
    <section className="card narrow" aria-labelledby="ci-h">
      <p className="eyebrow">Weekly check-in</p>
      <h1 id="ci-h" className="sr-only">Weekly stress check-in</h1>
      <label htmlFor="progress" className="small muted">Step {Math.min(step + 1, total)} of {total}</label>
      <progress id="progress" max={total} value={step + 1} />

      {step < n && (
        <>
          <p className="muted small">Think about the last 7 days. There are no right or wrong answers.</p>
          <StressQuestion question={meta.questions[step]} choices={meta.choices} value={answers[step]}
                          onChange={(v) => setAnswers(answers.map((a, i) => (i === step ? v : a)))} />
        </>
      )}

      {step === safetyStep && (
        <fieldset className="question">
          <legend>Have you had thoughts of harming yourself, or do you feel unsafe right now?</legend>
          <p className="hint">This answer is only used to show you support information. It is not saved.</p>
          <div className="choices">
            {[['No', false], ['Yes', true]].map(([label, val]) => (
              <label key={label} className={`choice ${safety === val ? 'selected' : ''}`}>
                <input type="radio" name="safety" checked={safety === val} onChange={() => setSafety(val)} />
                <span>{label}</span>
              </label>
            ))}
          </div>
        </fieldset>
      )}

      {step === reviewStep && (
        <>
          <h2>Review your answers</h2>
          <p className="muted small">Check everything looks right, then submit. Use “Change” to edit an answer.</p>
          <ol className="review">
            {meta.questions.map((q, i) => (
              <li key={q.id}>
                <span>{q.text.replace('In the last 7 days, how often have you ', 'You have ').replace('?', '')}</span>
                <strong>{meta.choices[answers[i]]}</strong>
                <button className="link" onClick={() => setStep(i)}>Change</button>
              </li>
            ))}
          </ol>
        </>
      )}

      <ErrorNote error={error} />
      <div className="actions">
        <button className="btn btn-ghost" onClick={back} disabled={step === 0 || busy}>Back</button>
        {step < reviewStep
          ? <button className="btn" onClick={next} disabled={!stepAnswered}>{step === safetyStep ? 'Review' : 'Next'}</button>
          : <button className="btn" onClick={submit} disabled={busy || answers.some((a) => a === null)}>{busy ? 'Submitting…' : 'Submit check-in'}</button>}
      </div>
    </section>
  );
}
