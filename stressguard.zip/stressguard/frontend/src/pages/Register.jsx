import { useState } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth.jsx';
import { ErrorNote } from '../components/Common.jsx';
import { AuthLayout } from './Login.jsx';

export default function Register() {
  const { user, register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ displayName: '', email: '', password: '', consent: false });
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);

  if (user) return <Navigate to="/" replace />;
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await register({
        displayName: form.displayName, email: form.email, password: form.password,
        consentAssessmentStorage: form.consent,
      });
      navigate('/', { replace: true });
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  }

  const fe = error?.fields || {};
  return (
    <AuthLayout title="Create your account" subtitle="Takes under a minute. No devices or sensors needed.">
      <form onSubmit={submit} noValidate>
        <ErrorNote error={error} />
        <label className="field">Name
          <input autoComplete="name" required maxLength={100} value={form.displayName} onChange={set('displayName')} aria-invalid={!!fe.displayName} />
          {fe.displayName && <span className="field-error">{fe.displayName}</span>}
        </label>
        <label className="field">Email
          <input type="email" autoComplete="email" required value={form.email} onChange={set('email')} aria-invalid={!!fe.email} />
          {fe.email && <span className="field-error">{fe.email}</span>}
        </label>
        <label className="field">Password
          <input type="password" autoComplete="new-password" required minLength={8} value={form.password} onChange={set('password')} aria-invalid={!!fe.password} aria-describedby="pw-hint" />
          <span id="pw-hint" className={fe.password ? 'field-error' : 'hint'}>
            {fe.password || 'At least 8 characters with upper-case, lower-case and a number.'}
          </span>
        </label>
        <fieldset className="consent-box">
          <legend>Your data, your choice</legend>
          <p className="small">
            StressGuard stores only the answers you submit, your scores and your account details. We never use cameras,
            microphones, sensors or location. You can withdraw consent, export or delete everything at any time in
            Privacy settings.
          </p>
          <label className="check">
            <input type="checkbox" checked={form.consent} onChange={set('consent')} />
            <span>I agree to StressGuard storing my check-in answers so I can see my history and trends.</span>
          </label>
          <p className="hint">You can also decide later — you cannot submit a check-in until you agree.</p>
        </fieldset>
        <button className="btn btn-block" disabled={busy}>{busy ? 'Creating…' : 'Create account'}</button>
      </form>
      <p className="small center">Already registered? <Link to="/login">Sign in</Link></p>
    </AuthLayout>
  );
}
