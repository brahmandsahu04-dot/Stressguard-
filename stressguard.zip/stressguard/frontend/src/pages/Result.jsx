import { useEffect, useState } from 'react';
import { Link, useLocation, useParams } from 'react-router-dom';
import { api } from '../api.js';
import { ErrorNote, Loading, ResultView } from '../components/Common.jsx';

export default function Result() {
  const { id } = useParams();
  const location = useLocation();
  const fromSubmit = location.state?.result?.id === id ? location.state.result : null;
  const [result, setResult] = useState(fromSubmit);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (fromSubmit) return;
    setResult(null);
    api.assessment(id).then(setResult).catch(setError);
  }, [id, fromSubmit]);

  if (error) return <><ErrorNote error={error} /><Link to="/history">Back to history</Link></>;
  if (!result) return <Loading />;
  return (
    <>
      <ResultView result={result} />
      <p><Link className="btn" to="/">Back to dashboard</Link> <Link className="btn btn-ghost" to="/history">History</Link></p>
    </>
  );
}
