import { useEffect, useState } from 'react';
import { api } from '../api.js';
import { CATEGORY_LABEL, ErrorNote, Loading } from '../components/Common.jsx';

const CATEGORIES = ['STRESS', 'MOOD', 'SLEEP', 'WORKLOAD', 'CONCENTRATION'];

export default function Admin() {
  const [stats, setStats] = useState(null);
  const [questions, setQuestions] = useState(null);
  const [draft, setDraft] = useState({ text: '', category: 'STRESS' });
  const [error, setError] = useState(null);

  const load = () => Promise.all([api.adminStats(), api.adminQuestions()])
    .then(([s, q]) => { setStats(s); setQuestions(q); }).catch(setError);
  useEffect(() => { load(); }, []);

  async function save(q, changes) {
    setError(null);
    try {
      const updated = await api.adminUpdateQuestion(q.id, { text: q.text, category: q.category, active: q.active, ...changes });
      setQuestions(questions.map((x) => (x.id === q.id ? updated : x)));
    } catch (e) { setError(e); }
  }

  async function add(e) {
    e.preventDefault();
    setError(null);
    try {
      await api.adminCreateQuestion({ ...draft, active: true });
      setDraft({ text: '', category: 'STRESS' });
      load();
    } catch (err) { setError(err); }
  }

  if (!stats || !questions) return error ? <ErrorNote error={error} /> : <Loading />;
  const bands = stats.bandDistribution;
  const totalBands = Object.values(bands).reduce((a, b) => a + b, 0) || 1;

  return (
    <>
      <h1>Administration</h1>
      <p className="muted">Aggregate figures only. Administrators cannot see individual answers.</p>
      <ErrorNote error={error} />

      <div className="grid stats">
        <div className="card stat"><p className="eyebrow">Registered users</p><p className="big-score">{stats.totalUsers}</p></div>
        <div className="card stat"><p className="eyebrow">Check-ins (all)</p><p className="big-score">{stats.totalAssessments}</p></div>
        <div className="card stat"><p className="eyebrow">Check-ins (7 days)</p><p className="big-score">{stats.assessmentsLast7Days}</p></div>
      </div>

      <section className="card" aria-labelledby="dist-h">
        <h2 id="dist-h">Indicator distribution</h2>
        <ul className="cat-list">
          {['LOW', 'MODERATE', 'HIGH'].map((b) => (
            <li key={b}>
              <span className="cat-name">{b[0] + b.slice(1).toLowerCase()}</span>
              <span className="bar" aria-hidden="true"><span style={{ width: `${(bands[b] / totalBands) * 100}%` }} /></span>
              <span className="cat-val">{bands[b]}</span>
            </li>
          ))}
        </ul>
      </section>

      <section className="card" aria-labelledby="q-h">
        <h2 id="q-h">Questionnaire items</h2>
        <p className="muted small">Changing the number of active items applies to new check-ins only. Use the status switch to retire an item.</p>
        <div className="table-wrap">
          <table>
            <thead><tr><th scope="col">#</th><th scope="col">Question</th><th scope="col">Category</th><th scope="col">Active</th></tr></thead>
            <tbody>
              {questions.map((q) => (
                <tr key={q.id}>
                  <td>{q.position}</td>
                  <td><input aria-label={`Text of question ${q.position}`} defaultValue={q.text}
                             onBlur={(e) => e.target.value.trim() && e.target.value !== q.text && save(q, { text: e.target.value })} /></td>
                  <td>
                    <select aria-label={`Category of question ${q.position}`} value={q.category} onChange={(e) => save(q, { category: e.target.value })}>
                      {CATEGORIES.map((c) => <option key={c} value={c}>{CATEGORY_LABEL[c]}</option>)}
                    </select>
                  </td>
                  <td>
                    <button className={`switch ${q.active ? 'on' : ''}`} role="switch" aria-checked={q.active}
                            aria-label={`Question ${q.position} active`} onClick={() => save(q, { active: !q.active })}><span /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <form onSubmit={add} className="add-q">
          <label className="field grow">New question
            <input value={draft.text} maxLength={500} onChange={(e) => setDraft({ ...draft, text: e.target.value })} required />
          </label>
          <label className="field">Category
            <select value={draft.category} onChange={(e) => setDraft({ ...draft, category: e.target.value })}>
              {CATEGORIES.map((c) => <option key={c} value={c}>{CATEGORY_LABEL[c]}</option>)}
            </select>
          </label>
          <button className="btn" disabled={!draft.text.trim()}>Add</button>
        </form>
      </section>
    </>
  );
}
