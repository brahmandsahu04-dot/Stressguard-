import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';
import BreathingGuide from '../components/BreathingGuide.jsx';
import { CATEGORY_LABEL, ErrorNote, Loading, formatDate } from '../components/Common.jsx';

export default function Wellness() {
  const [state, setState] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    (async () => {
      const [library, history] = await Promise.all([api.resources(), api.history()]);
      const latest = history[0] ? await api.assessment(history[0].id) : null;
      setState({ library, latest });
    })().catch(setError);
  }, []);

  if (error) return <ErrorNote error={error} />;
  if (!state) return <Loading />;

  const { library, latest } = state;
  const grouped = library.reduce((acc, r) => ({ ...acc, [r.category]: [...(acc[r.category] || []), r] }), {});

  return (
    <>
      <h1>Wellness suggestions</h1>
      <p className="muted lead">Small, practical ideas. They are general wellbeing tips, not treatment.</p>

      {latest ? (
        <section aria-labelledby="for-you">
          <h2 id="for-you">Based on your check-in on {formatDate(latest.completedAt)}</h2>
          <div className="grid">
            {latest.recommendations.map((r) => (
              <article className="card tip" key={r.id}>
                <span className="chip">{CATEGORY_LABEL[r.category] || r.category}</span>
                <h3>{r.title}</h3>
                <p>{r.content}</p>
              </article>
            ))}
          </div>
        </section>
      ) : (
        <div className="alert alert-info">Complete a <Link to="/checkin">check-in</Link> to get suggestions matched to how you have been feeling.</div>
      )}

      <BreathingGuide />

      <section aria-labelledby="lib-h">
        <h2 id="lib-h">All ideas</h2>
        {Object.entries(grouped).map(([cat, items]) => (
          <details key={cat} className="card acc">
            <summary>{CATEGORY_LABEL[cat] || cat} <span className="muted small">({items.length})</span></summary>
            {items.map((r) => (
              <div key={r.id} className="acc-item"><h3>{r.title}</h3><p>{r.content}</p></div>
            ))}
          </details>
        ))}
      </section>
    </>
  );
}
