import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';
import { useAuth } from '../auth.jsx';
import TrendChart from '../components/TrendChart.jsx';
import { BandBadge, EmptyState, ErrorNote, Loading, formatDate } from '../components/Common.jsx';

const DIRECTION = {
  DECREASING: 'Your latest check-in is lower than your earlier average — a positive sign.',
  STABLE: 'Your latest check-in is close to your earlier average.',
  INCREASING: 'Your latest check-in is higher than your earlier average. Be kind to yourself and see the suggestions.',
  INSUFFICIENT_DATA: 'Complete at least two check-ins in this period to see a trend.',
};

export default function Dashboard() {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    Promise.all([api.history(), api.trends(30), api.reminder(), api.consents()])
      .then(([history, trend, reminder, consents]) => setData({ history, trend, reminder, consents }))
      .catch(setError);
  }, []);

  if (error) return <ErrorNote error={error} />;
  if (!data) return <Loading />;

  const { history, trend, reminder, consents } = data;
  const latest = history[0];
  const consentOn = consents.find((c) => c.purpose === 'ASSESSMENT_STORAGE')?.active;

  return (
    <>
      <h1>Hello, {user.displayName.split(' ')[0]}</h1>
      <p className="muted lead">A few minutes of reflection each week can help you notice how you are really doing.</p>

      {reminder.due && (
        <div className="alert alert-info" role="status">
          It is time for your weekly check-in. <Link to="/checkin">Start now</Link>
        </div>
      )}
      {!consentOn && (
        <div className="alert alert-info" role="status">
          To save check-ins you need to give consent first. <Link to="/privacy">Review privacy settings</Link>
        </div>
      )}

      {!latest ? (
        <EmptyState title="No check-ins yet">Your first check-in takes about two minutes. Your results will appear here.</EmptyState>
      ) : (
        <>
          <div className="grid stats">
            <section className="card stat" aria-label="Latest check-in">
              <p className="eyebrow">Latest check-in</p>
              <p className="big-score">{latest.totalScore}<span className="muted"> / {latest.maxScore}</span></p>
              <BandBadge band={latest.band} />
              <p className="muted small">{formatDate(latest.completedAt)}</p>
              <Link to={`/result/${latest.id}`}>View details</Link>
            </section>
            <section className="card stat" aria-label="Trend">
              <p className="eyebrow">Last 30 days</p>
              <p className="big-score">{trend.points.length}<span className="muted"> check-in{trend.points.length === 1 ? '' : 's'}</span></p>
              <p className="small">{DIRECTION[trend.direction]}</p>
              {trend.averagePercent != null && <p className="muted small">Average: {trend.averagePercent}% of maximum</p>}
            </section>
            <section className="card stat" aria-label="Total check-ins">
              <p className="eyebrow">All time</p>
              <p className="big-score">{history.length}<span className="muted"> completed</span></p>
              <p className="muted small">Reminders: {reminder.enabled ? `on — next ${formatDate(reminder.nextDue)}` : 'off'}</p>
              <Link to="/privacy">Change reminders</Link>
            </section>
          </div>

          <section className="card" aria-labelledby="trend-h">
            <h2 id="trend-h">Your recent trend</h2>
            {trend.points.length ? <TrendChart points={trend.points} /> : <p className="muted">No check-ins in the last 30 days.</p>}
            <p><Link to="/history">See full history</Link></p>
          </section>
        </>
      )}

      <p><Link className="btn" to="/checkin">{latest ? 'Start a new check-in' : 'Start your first check-in'}</Link>{' '}
        <Link className="btn btn-ghost" to="/wellness">Wellness tips</Link></p>
    </>
  );
}
