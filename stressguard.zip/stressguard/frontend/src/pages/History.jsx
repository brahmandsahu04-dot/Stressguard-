import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';
import TrendChart from '../components/TrendChart.jsx';
import { BandBadge, EmptyState, ErrorNote, Loading, formatDate } from '../components/Common.jsx';

const RANGES = [{ days: 7, label: 'Week' }, { days: 30, label: 'Month' }, { days: 90, label: '3 months' }];

export default function History() {
  const [days, setDays] = useState(30);
  const [trend, setTrend] = useState(null);
  const [history, setHistory] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => { api.history().then(setHistory).catch(setError); }, []);
  useEffect(() => { setTrend(null); api.trends(days).then(setTrend).catch(setError); }, [days]);

  if (error) return <ErrorNote error={error} />;
  if (!history) return <Loading />;
  if (!history.length) return <EmptyState title="No history yet">Complete a check-in and your history will appear here.</EmptyState>;

  return (
    <>
      <h1>Your history</h1>
      <section className="card" aria-labelledby="tr-h">
        <div className="row-between">
          <h2 id="tr-h">Trend</h2>
          <div className="seg" role="group" aria-label="Time period">
            {RANGES.map((r) => (
              <button key={r.days} className={days === r.days ? 'on' : ''} aria-pressed={days === r.days} onClick={() => setDays(r.days)}>{r.label}</button>
            ))}
          </div>
        </div>
        {!trend ? <Loading /> : trend.points.length === 0
          ? <p className="muted">No check-ins in this period.</p>
          : (
            <>
              <TrendChart points={trend.points} />
              <p className="small">
                {trend.points.length} check-in{trend.points.length === 1 ? '' : 's'} · average {trend.averagePercent}% of maximum
                {trend.changePercent != null && <> · latest is {Math.abs(trend.changePercent)} points {trend.changePercent < 0 ? 'lower' : trend.changePercent > 0 ? 'higher' : 'the same'} than your earlier average</>}
              </p>
            </>
          )}
      </section>

      <section className="card" aria-labelledby="all-h">
        <h2 id="all-h">All check-ins</h2>
        <div className="table-wrap">
          <table>
            <thead><tr><th scope="col">Date</th><th scope="col">Score</th><th scope="col">Indicator</th><th scope="col"><span className="sr-only">Details</span></th></tr></thead>
            <tbody>
              {history.map((h) => (
                <tr key={h.id}>
                  <td>{formatDate(h.completedAt, true)}</td>
                  <td>{h.totalScore} / {h.maxScore}</td>
                  <td><BandBadge band={h.band} /></td>
                  <td><Link to={`/result/${h.id}`}>View</Link></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}
