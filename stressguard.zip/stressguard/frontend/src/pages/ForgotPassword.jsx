import { useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';
import { ErrorNote } from '../components/Common.jsx';
import { AuthLayout } from './Login.jsx';

export default function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [token, setToken] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState(null);
  const [error, setError] = useState(null);

  async function request(e) {
    e.preventDefault();
    setError(null);
    try {
      const r = await api.forgot(email);
      setMessage(r.message);
    } catch (err) { setError(err); }
  }

  async function reset(e) {
    e.preventDefault();
    setError(null);
    try {
      const r = await api.reset(token.trim(), password);
      setMessage(r.message);
      setToken(''); setPassword('');
    } catch (err) { setError(err); }
  }

  return (
    <AuthLayout title="Reset your password" subtitle="We will issue a one-time reset token for your account.">
      <ErrorNote error={error} />
      {message && <div className="alert alert-ok" role="status">{message}</div>}
      <form onSubmit={request}>
        <label className="field">Email
          <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
        </label>
        <button className="btn btn-block" disabled={!email}>Request reset token</button>
      </form>
      <details className="reset-details">
        <summary>I already have a reset token</summary>
        <form onSubmit={reset}>
          <p className="hint">
            This prototype has no e-mail server, so in development the token is printed in the backend console.
          </p>
          <label className="field">Reset token
            <input required value={token} onChange={(e) => setToken(e.target.value)} autoComplete="off" />
          </label>
          <label className="field">New password
            <input type="password" required minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="new-password" />
          </label>
          <button className="btn btn-block" disabled={!token || !password}>Set new password</button>
        </form>
      </details>
      <p className="small center"><Link to="/login">Back to sign in</Link></p>
    </AuthLayout>
  );
}
