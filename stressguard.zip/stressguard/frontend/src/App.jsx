import { Navigate, NavLink, Route, Routes, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from './auth.jsx';
import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';
import ForgotPassword from './pages/ForgotPassword.jsx';
import Dashboard from './pages/Dashboard.jsx';
import CheckIn from './pages/CheckIn.jsx';
import History from './pages/History.jsx';
import Result from './pages/Result.jsx';
import Wellness from './pages/Wellness.jsx';
import Privacy from './pages/Privacy.jsx';
import Admin from './pages/Admin.jsx';

function Protected({ admin = false }) {
  const { user } = useAuth();
  const location = useLocation();
  if (!user) return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  if (admin && user.role !== 'ADMIN') return <Navigate to="/" replace />;
  return <Outlet />;
}

function Shell() {
  const { user, logout } = useAuth();
  return (
    <>
      <a className="skip-link" href="#main">Skip to content</a>
      <header className="topbar">
        <div className="topbar-inner">
          <NavLink to="/" className="brand" aria-label="StressGuard home">
            <svg width="26" height="26" viewBox="0 0 32 32" aria-hidden="true">
              <circle cx="16" cy="16" r="14" fill="currentColor" />
              <path d="M9 17l5 5 9-12" stroke="#fff" strokeWidth="3" fill="none" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            StressGuard
          </NavLink>
          <nav aria-label="Main">
            <NavLink to="/" end>Dashboard</NavLink>
            <NavLink to="/checkin">Check-in</NavLink>
            <NavLink to="/history">History</NavLink>
            <NavLink to="/wellness">Wellness</NavLink>
            <NavLink to="/privacy">Privacy</NavLink>
            {user.role === 'ADMIN' && <NavLink to="/admin">Admin</NavLink>}
          </nav>
          <div className="topbar-user">
            <span className="muted small hide-sm">{user.displayName}</span>
            <button className="btn btn-ghost btn-sm" onClick={logout}>Sign out</button>
          </div>
        </div>
      </header>
      <main id="main" className="container">
        <Outlet />
      </main>
      <footer className="footer">
        StressGuard is a self-reported wellness indicator and is not a medical diagnosis or a substitute for
        professional care. If you are in immediate danger, call <strong>112</strong>.
      </footer>
    </>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route element={<Protected />}>
        <Route element={<Shell />}>
          <Route index element={<Dashboard />} />
          <Route path="checkin" element={<CheckIn />} />
          <Route path="history" element={<History />} />
          <Route path="result/:id" element={<Result />} />
          <Route path="wellness" element={<Wellness />} />
          <Route path="privacy" element={<Privacy />} />
          <Route element={<Protected admin />}>
            <Route path="admin" element={<Admin />} />
          </Route>
        </Route>
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
