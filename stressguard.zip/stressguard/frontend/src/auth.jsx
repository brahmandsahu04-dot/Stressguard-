import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { api, session } from './api.js';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => (session.token() ? session.user() : null));

  useEffect(() => {
    const onLogout = () => setUser(null);
    window.addEventListener('sg:logout', onLogout);
    return () => window.removeEventListener('sg:logout', onLogout);
  }, []);

  const finish = useCallback((res) => {
    session.save(res.token, res.user);
    setUser(res.user);
    return res.user;
  }, []);

  const value = {
    user,
    login: async (email, password) => finish(await api.login({ email, password })),
    register: async (form) => finish(await api.register(form)),
    logout: () => { session.clear(); setUser(null); },
  };
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
