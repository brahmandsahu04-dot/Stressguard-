import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// In development the React app calls /api/... and Vite forwards it to the Spring Boot server.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: { '/api': { target: process.env.API_URL || 'http://localhost:8080', changeOrigin: true } },
  },
});
