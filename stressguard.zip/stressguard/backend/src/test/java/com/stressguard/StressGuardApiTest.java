package com.stressguard;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

/** Integration tests that implement the test cases TC-01 to TC-10 of the project report. */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("dev")
class StressGuardApiTest {

    private static final String PASSWORD = "Passw0rdX";

    @Autowired MockMvc mvc;
    @Autowired ObjectMapper om;

    // ----------------------------------------------------------------- helpers

    private ResultActions postJson(String url, String token, Object body) throws Exception {
        var req = post(url).contentType(MediaType.APPLICATION_JSON).content(om.writeValueAsString(body));
        if (token != null) req.header("Authorization", "Bearer " + token);
        return mvc.perform(req);
    }

    private ResultActions getAuth(String url, String token) throws Exception {
        var req = get(url);
        if (token != null) req.header("Authorization", "Bearer " + token);
        return mvc.perform(req);
    }

    private static String newEmail() {
        return "user-" + UUID.randomUUID() + "@example.com";
    }

    private JsonNode json(ResultActions r) throws Exception {
        return om.readTree(r.andReturn().getResponse().getContentAsString());
    }

    private String register(String email, boolean consent) throws Exception {
        Map<String, Object> body = Map.of("email", email, "password", PASSWORD,
                "displayName", "Test User", "consentAssessmentStorage", consent);
        return json(postJson("/api/auth/register", null, body).andExpect(status().isCreated())).get("token").asText();
    }

    private Map<String, Object> assessment(List<Integer> answers) {
        return Map.of("questionnaireVersion", "v1", "answers", answers, "consentConfirmed", true);
    }

    private List<Integer> same(int value) {
        return Collections.nCopies(10, value);
    }

    // ------------------------------------------------------------------ tests

    @Test
    void tc01_validRegistrationAndWeakPassword() throws Exception {
        String token = register(newEmail(), true);
        assertFalse(token.isBlank());

        postJson("/api/auth/register", null, Map.of("email", newEmail(), "password", "weak", "displayName", "X"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("VALIDATION_FAILED"));
    }

    @Test
    void tc02_invalidLoginGivesGenericError() throws Exception {
        String email = newEmail();
        register(email, true);
        String wrongPassword = postJson("/api/auth/login", null, Map.of("email", email, "password", "Wrong1234"))
                .andExpect(status().isUnauthorized()).andReturn().getResponse().getContentAsString();
        String unknownUser = postJson("/api/auth/login", null, Map.of("email", newEmail(), "password", "Wrong1234"))
                .andExpect(status().isUnauthorized()).andReturn().getResponse().getContentAsString();
        assertEquals(om.readTree(wrongPassword).get("message"), om.readTree(unknownUser).get("message"));
    }

    @Test
    void accountLocksAfterRepeatedFailures() throws Exception {
        String email = newEmail();
        register(email, true);
        for (int i = 0; i < 5; i++) {
            postJson("/api/auth/login", null, Map.of("email", email, "password", "Wrong1234"))
                    .andExpect(status().isUnauthorized());
        }
        postJson("/api/auth/login", null, Map.of("email", email, "password", PASSWORD))
                .andExpect(status().isTooManyRequests());
    }

    @Test
    void tc03_validAssessmentIsStoredAndScored() throws Exception {
        String token = register(newEmail(), true);
        postJson("/api/assessments", token, assessment(same(2)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.totalScore").value(20))
                .andExpect(jsonPath("$.maxScore").value(40))
                .andExpect(jsonPath("$.band").value("MODERATE"))
                .andExpect(jsonPath("$.disclaimer").isNotEmpty());
        getAuth("/api/assessments/me", token).andExpect(status().isOk()).andExpect(jsonPath("$.length()").value(1));
    }

    @Test
    void highScoreShowsSupportContacts() throws Exception {
        String token = register(newEmail(), true);
        postJson("/api/assessments", token, assessment(same(4)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.band").value("HIGH"))
                .andExpect(jsonPath("$.supportContacts.length()").value(3));
    }

    @Test
    void tc04_missingResponseIsRejected() throws Exception {
        String token = register(newEmail(), true);
        postJson("/api/assessments", token, assessment(Collections.nCopies(9, 2)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("ANSWER_COUNT"));
        getAuth("/api/assessments/me", token).andExpect(jsonPath("$.length()").value(0));
    }

    @Test
    void tc05_outOfRangeValueIsRejected() throws Exception {
        String token = register(newEmail(), true);
        List<Integer> answers = new java.util.ArrayList<>(same(2));
        answers.set(3, 5);
        postJson("/api/assessments", token, assessment(answers)).andExpect(status().isBadRequest());
    }

    @Test
    void tc06_userCannotReadAnotherUsersAssessment() throws Exception {
        String a = register(newEmail(), true);
        String b = register(newEmail(), true);
        String id = json(postJson("/api/assessments", a, assessment(same(1))).andExpect(status().isCreated())).get("id").asText();
        getAuth("/api/assessments/" + id, a).andExpect(status().isOk());
        getAuth("/api/assessments/" + id, b).andExpect(status().isForbidden());
        getAuth("/api/assessments/me", b).andExpect(jsonPath("$.length()").value(0));
    }

    @Test
    void tc07_withdrawnConsentStopsCollection() throws Exception {
        String token = register(newEmail(), true);
        mvc.perform(put("/api/consents").header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON)
                .content(om.writeValueAsString(Map.of("purpose", "ASSESSMENT_STORAGE", "granted", false))))
                .andExpect(status().isOk());
        postJson("/api/assessments", token, assessment(same(1)))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value("CONSENT_REQUIRED"));
    }

    @Test
    void submissionWithoutAnyConsentIsRejected() throws Exception {
        String token = register(newEmail(), false);
        postJson("/api/assessments", token, assessment(same(1))).andExpect(status().isForbidden());
    }

    @Test
    void tc08_accountDeletionRemovesDataAndAccess() throws Exception {
        String email = newEmail();
        String token = register(email, true);
        postJson("/api/assessments", token, assessment(same(1))).andExpect(status().isCreated());

        mvc.perform(delete("/api/privacy/account").header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON)
                .content(om.writeValueAsString(Map.of("password", "Wrong1234"))))
                .andExpect(status().isForbidden());

        mvc.perform(delete("/api/privacy/account").header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON)
                .content(om.writeValueAsString(Map.of("password", PASSWORD))))
                .andExpect(status().isNoContent());

        postJson("/api/auth/login", null, Map.of("email", email, "password", PASSWORD)).andExpect(status().isUnauthorized());
        getAuth("/api/assessments/me", token).andExpect(status().isUnauthorized());
    }

    @Test
    void tc09_trendShowsOnlyOwnRecordsInOrder() throws Exception {
        String a = register(newEmail(), true);
        String b = register(newEmail(), true);
        postJson("/api/assessments", a, assessment(same(1))).andExpect(status().isCreated());
        postJson("/api/assessments", a, assessment(same(3))).andExpect(status().isCreated());
        postJson("/api/assessments", b, assessment(same(0))).andExpect(status().isCreated());

        getAuth("/api/assessments/trends?days=30", a).andExpect(status().isOk())
                .andExpect(jsonPath("$.points.length()").value(2))
                .andExpect(jsonPath("$.points[0].totalScore").value(10))
                .andExpect(jsonPath("$.points[1].totalScore").value(30))
                .andExpect(jsonPath("$.direction").value("INCREASING"));
    }

    @Test
    void remindersAreOffByDefaultAndCanBeToggled() throws Exception {
        String token = register(newEmail(), true);
        getAuth("/api/reminders", token).andExpect(jsonPath("$.enabled").value(false));
        mvc.perform(put("/api/reminders").header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON)
                .content(om.writeValueAsString(Map.of("enabled", true))))
                .andExpect(status().isOk()).andExpect(jsonPath("$.enabled").value(true));
    }

    @Test
    void exportContainsOwnData() throws Exception {
        String email = newEmail();
        String token = register(email, true);
        postJson("/api/assessments", token, assessment(same(2))).andExpect(status().isCreated());
        getAuth("/api/privacy/export", token).andExpect(status().isOk())
                .andExpect(jsonPath("$.profile.email").value(email))
                .andExpect(jsonPath("$.assessments.length()").value(1))
                .andExpect(jsonPath("$.assessments[0].answers.length()").value(10));
    }

    @Test
    void protectedEndpointsNeedAuthentication() throws Exception {
        getAuth("/api/assessments/me", null).andExpect(status().isUnauthorized());
        getAuth("/api/questions", null).andExpect(status().isUnauthorized());
    }

    @Test
    void adminEndpointsAreRestrictedToAdmins() throws Exception {
        String user = register(newEmail(), true);
        getAuth("/api/admin/stats", user).andExpect(status().isForbidden());

        String admin = json(postJson("/api/auth/login", null,
                Map.of("email", "admin@stressguard.local", "password", "Admin@12345")).andExpect(status().isOk()))
                .get("token").asText();
        getAuth("/api/admin/stats", admin).andExpect(status().isOk()).andExpect(jsonPath("$.totalUsers").isNumber());
        getAuth("/api/admin/questions", admin).andExpect(status().isOk());
    }

    @Test
    void passwordResetFlowRejectsBadToken() throws Exception {
        postJson("/api/auth/forgot-password", null, Map.of("email", newEmail())).andExpect(status().isOk());
        postJson("/api/auth/reset-password", null, Map.of("token", "nope", "newPassword", "NewPassw0rd"))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("INVALID_TOKEN"));
    }
}
