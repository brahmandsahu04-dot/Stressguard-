package com.stressguard;

import static org.junit.jupiter.api.Assertions.*;

import com.stressguard.scoring.AssessmentResult;
import com.stressguard.scoring.StressBand;
import com.stressguard.scoring.StressScoringService;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import org.junit.jupiter.api.Test;

class StressScoringServiceTest {

    private final StressScoringService service = new StressScoringService();

    private static List<Integer> answersWithSum(int size, int sum) {
        // spread the sum over `size` answers, each between 0 and 4
        return IntStream.range(0, size).mapToObj(i -> Math.min(4, Math.max(0, sum - 4 * i))).collect(Collectors.toList());
    }

    @Test
    void allZeroIsLow() {
        AssessmentResult r = service.calculate(Collections.nCopies(10, 0));
        assertEquals(0, r.totalScore());
        assertEquals(40, r.maxScore());
        assertEquals(StressBand.LOW, r.band());
    }

    @Test
    void bandBoundariesForTenQuestions() {
        assertEquals(StressBand.LOW, service.calculate(answersWithSum(10, 13)).band());
        assertEquals(StressBand.MODERATE, service.calculate(answersWithSum(10, 14)).band());
        assertEquals(StressBand.MODERATE, service.calculate(answersWithSum(10, 26)).band());
        assertEquals(StressBand.HIGH, service.calculate(answersWithSum(10, 27)).band());
        assertEquals(StressBand.HIGH, service.calculate(Collections.nCopies(10, 4)).band());
    }

    @Test
    void totalIsPlainSum() {
        assertEquals(10, service.calculate(List.of(1, 2, 3, 4, 0)).totalScore());
    }

    @Test
    void emptyOrNullIsRejected() {
        assertThrows(IllegalArgumentException.class, () -> service.calculate(List.of()));
        assertThrows(IllegalArgumentException.class, () -> service.calculate(null));
    }

    @Test
    void outOfRangeIsRejected() {
        assertThrows(IllegalArgumentException.class, () -> service.calculate(List.of(1, 5)));
        assertThrows(IllegalArgumentException.class, () -> service.calculate(List.of(-1, 2)));
    }

    @Test
    void guidanceIsSupportiveForHighBand() {
        String guidance = service.calculate(Collections.nCopies(10, 4)).guidance();
        assertTrue(guidance.toLowerCase().contains("trusted person"));
    }
}
