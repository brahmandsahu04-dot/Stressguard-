package com.stressguard.repo;

import com.stressguard.domain.Assessment;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface AssessmentRepository extends JpaRepository<Assessment, UUID> {
    List<Assessment> findByUser_IdOrderByCompletedAtDesc(UUID userId);

    List<Assessment> findByUser_IdAndCompletedAtAfterOrderByCompletedAtAsc(UUID userId, Instant after);

    long countByCompletedAtAfter(Instant after);

    @Query("select a.severityBand, count(a) from Assessment a group by a.severityBand")
    List<Object[]> countByBand();
}
