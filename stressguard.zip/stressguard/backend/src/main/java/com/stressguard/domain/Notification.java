package com.stressguard.domain;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.UUID;

/** Stores the optional in-app check-in reminder of a user. */
@Entity
@Table(name = "notifications")
public class Notification {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "notification_id")
    private UUID id;

    @Column(name = "user_id", nullable = false)
    private UUID userId;

    @Column(nullable = false, length = 30)
    private String type;

    /** ENABLED or DISABLED. */
    @Column(nullable = false, length = 20)
    private String status;

    @Column(name = "scheduled_at")
    private Instant scheduledAt;

    protected Notification() {}

    public Notification(UUID userId, String type, String status, Instant scheduledAt) {
        this.userId = userId;
        this.type = type;
        this.status = status;
        this.scheduledAt = scheduledAt;
    }

    public UUID getId() { return id; }
    public UUID getUserId() { return userId; }
    public String getType() { return type; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Instant getScheduledAt() { return scheduledAt; }
    public void setScheduledAt(Instant scheduledAt) { this.scheduledAt = scheduledAt; }
}
