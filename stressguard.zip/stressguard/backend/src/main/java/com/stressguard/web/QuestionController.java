package com.stressguard.web;

import com.stressguard.config.AppProperties;
import com.stressguard.dto.Dtos.QuestionDto;
import com.stressguard.service.AssessmentService;
import java.util.List;
import java.util.Map;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/questions")
public class QuestionController {

    private final AssessmentService service;
    private final AppProperties props;

    public QuestionController(AssessmentService service, AppProperties props) {
        this.service = service;
        this.props = props;
    }

    @GetMapping
    @PreAuthorize("isAuthenticated()")
    public Map<String, Object> active() {
        List<QuestionDto> questions = service.activeQuestions();
        return Map.of("version", props.questionnaireVersion(),
                "choices", List.of("Never", "Almost never", "Sometimes", "Fairly often", "Very often"),
                "questions", questions);
    }
}
