package com.stressguard.domain;

import jakarta.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "questions")
public class Question {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "question_id")
    private UUID id;

    @Column(nullable = false, length = 500)
    private String text;

    /** STRESS, MOOD, SLEEP, WORKLOAD or CONCENTRATION. */
    @Column(nullable = false, length = 30)
    private String category;

    @Column(nullable = false)
    private boolean active = true;

    @Column(nullable = false, length = 40)
    private String version;

    @Column(nullable = false)
    private int position;

    protected Question() {}

    public Question(String text, String category, String version, int position) {
        this.text = text;
        this.category = category;
        this.version = version;
        this.position = position;
    }

    public UUID getId() { return id; }
    public String getText() { return text; }
    public void setText(String text) { this.text = text; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
    public String getVersion() { return version; }
    public int getPosition() { return position; }
}
