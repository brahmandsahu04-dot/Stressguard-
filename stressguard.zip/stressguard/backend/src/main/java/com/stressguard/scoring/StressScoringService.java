package com.stressguard.scoring;

import java.util.List;
import org.springframework.stereotype.Service;

/**
 * Transparent scoring rules of StressGuard.
 *
 * <p>Every answer is a frequency from 0 (Never) to 4 (Very often); the total is the plain sum.
 * Bands are based on the share of the maximum possible score: up to 33 % is LOW, up to 66 % is
 * MODERATE and anything above is HIGH. For the default 10-item questionnaire (maximum 40) this
 * gives 0-13 / 14-26 / 27-40.
 *
 * <p>These cut-offs are illustrative wellness indicators, NOT validated clinical thresholds. If a
 * standardised instrument such as the PSS is adopted, its own scoring rules and licence terms
 * must replace this class.
 */
@Service
public class StressScoringService {

    public static final int MAX_ANSWER = 4;

    public AssessmentResult calculate(List<Integer> answers) {
        if (answers == null || answers.isEmpty()) {
            throw new IllegalArgumentException("Responses are required");
        }
        int score = 0;
        for (Integer value : answers) {
            if (value == null || value < 0 || value > MAX_ANSWER) {
                throw new IllegalArgumentException("Invalid response");
            }
            score += value;
        }
        int max = answers.size() * MAX_ANSWER;
        StressBand band = bandFor(score, max);
        return new AssessmentResult(score, max, band, guidanceFor(band));
    }

    public StressBand bandFor(int score, int maxScore) {
        double percent = score * 100.0 / maxScore;
        if (percent <= 33) return StressBand.LOW;
        if (percent <= 66) return StressBand.MODERATE;
        return StressBand.HIGH;
    }

    public String guidanceFor(StressBand band) {
        return switch (band) {
            case LOW -> "Your reported stress is on the lower side. Continue healthy routines and regular check-ins.";
            case MODERATE -> "Your reported stress is moderate. Consider a short break and review your routine.";
            case HIGH -> "Your reported stress is on the higher side. Consider reaching out to a trusted person or a qualified professional.";
        };
    }
}
