package com.stressguard.web;

import com.stressguard.dto.Dtos.*;
import com.stressguard.service.AdminService;
import jakarta.validation.Valid;
import java.util.List;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    private final AdminService service;

    public AdminController(AdminService service) {
        this.service = service;
    }

    @GetMapping("/questions")
    public List<AdminQuestionDto> questions() {
        return service.listQuestions();
    }

    @PostMapping("/questions")
    public ResponseEntity<AdminQuestionDto> create(@Valid @RequestBody AdminQuestionRequest request,
                                                   Authentication authentication) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(CurrentUser.id(authentication), request));
    }

    @PutMapping("/questions/{id}")
    public AdminQuestionDto update(@PathVariable UUID id, @Valid @RequestBody AdminQuestionRequest request,
                                   Authentication authentication) {
        return service.update(CurrentUser.id(authentication), id, request);
    }

    @GetMapping("/stats")
    public StatsDto stats() {
        return service.stats();
    }
}
