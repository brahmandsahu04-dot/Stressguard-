package com.stressguard.web;

import com.stressguard.dto.Dtos.DeleteAccountRequest;
import com.stressguard.service.PrivacyService;
import jakarta.validation.Valid;
import java.util.Map;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/privacy")
public class PrivacyController {

    private final PrivacyService service;

    public PrivacyController(PrivacyService service) {
        this.service = service;
    }

    @GetMapping("/export")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Map<String, Object>> export(Authentication authentication) {
        Map<String, Object> data = service.export(CurrentUser.id(authentication));
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        ContentDisposition.attachment().filename("stressguard-data.json").build().toString())
                .body(data);
    }

    @DeleteMapping("/account")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Void> delete(@Valid @RequestBody DeleteAccountRequest request, Authentication authentication) {
        service.deleteAccount(CurrentUser.id(authentication), request.password());
        return ResponseEntity.noContent().build();
    }
}
