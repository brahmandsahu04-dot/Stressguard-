package com.stressguard.domain;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.UUID;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Table(name = "assessments")
public class Assessment {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "assessment_id")
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    private User user;

    @Column(name = "questionnaire_version", nullable = false, length = 40)
    private String questionnaireVersion;

    @Column(name = "total_score", nullable = false)
    private int totalScore;

    /** Highest score possible for the questionnaire used (kept so history stays correct if questions change). */
    @Column(name = "max_score", nullable = false)
    private int maxScore;

    @Column(name = "severity_band", nullable = false, length = 20)
    private String severityBand;

    @Column(name = "completed_at", nullable = false)
    private Instant completedAt;

    protected Assessment() {}

    public Assessment(User user, String questionnaireVersion, int totalScore, int maxScore,
                      String severityBand, Instant completedAt) {
        this.user = user;
        this.questionnaireVersion = questionnaireVersion;
        this.totalScore = totalScore;
        this.maxScore = maxScore;
        this.severityBand = severityBand;
        this.completedAt = completedAt;
    }

    public UUID getId() { return id; }
    public User getUser() { return user; }
    public String getQuestionnaireVersion() { return questionnaireVersion; }
    public int getTotalScore() { return totalScore; }
    public int getMaxScore() { return maxScore; }
    public String getSeverityBand() { return severityBand; }
    public Instant getCompletedAt() { return completedAt; }
}
