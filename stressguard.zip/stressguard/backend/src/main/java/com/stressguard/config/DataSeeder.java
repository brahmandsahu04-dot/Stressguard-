package com.stressguard.config;

import com.stressguard.domain.*;
import com.stressguard.repo.*;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/** Inserts the default questionnaire, wellness resources and (optionally) the first administrator. */
@Component
public class DataSeeder implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(DataSeeder.class);

    private final QuestionRepository questions;
    private final WellnessResourceRepository resources;
    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final AppProperties props;

    public DataSeeder(QuestionRepository questions, WellnessResourceRepository resources,
                      UserRepository users, PasswordEncoder encoder, AppProperties props) {
        this.questions = questions;
        this.resources = resources;
        this.users = users;
        this.encoder = encoder;
        this.props = props;
    }

    @Override
    public void run(ApplicationArguments args) {
        if (questions.count() == 0) seedQuestions();
        if (resources.count() == 0) seedResources();
        seedAdmin();
    }

    /**
     * Original wording written for this project (not a copy of any licensed scale). Each item asks
     * about the last 7 days and is answered 0 (Never) to 4 (Very often); higher always means more
     * reported stress, so no reverse scoring is needed.
     */
    private void seedQuestions() {
        String v = props.questionnaireVersion();
        String[][] items = {
                {"STRESS", "In the last 7 days, how often have you felt unable to control the important things in your life?"},
                {"STRESS", "In the last 7 days, how often have you felt nervous or tense?"},
                {"STRESS", "In the last 7 days, how often have you felt that difficulties were piling up so high that you could not overcome them?"},
                {"MOOD", "In the last 7 days, how often have you felt down, irritable or low on motivation?"},
                {"MOOD", "In the last 7 days, how often have you found little enjoyment in things you usually like doing?"},
                {"SLEEP", "In the last 7 days, how often have you had trouble falling asleep or staying asleep?"},
                {"SLEEP", "In the last 7 days, how often have you woken up feeling unrested?"},
                {"WORKLOAD", "In the last 7 days, how often have you felt overwhelmed by your studies, work or responsibilities?"},
                {"WORKLOAD", "In the last 7 days, how often have you felt you did not have enough time to finish what you needed to do?"},
                {"CONCENTRATION", "In the last 7 days, how often have you found it hard to concentrate on what you were doing?"},
        };
        for (int i = 0; i < items.length; i++) {
            questions.save(new Question(items[i][1], items[i][0], v, i + 1));
        }
        log.info("Seeded {} questions", items.length);
    }

    private void seedResources() {
        List<WellnessResource> list = List.of(
                new WellnessResource("STRESS", "Box breathing (2 minutes)",
                        "Breathe in for 4 counts, hold for 4, breathe out for 4, hold for 4. Repeat for about two minutes. If holding your breath feels uncomfortable, simply make the out-breath longer than the in-breath."),
                new WellnessResource("STRESS", "Name it to tame it",
                        "Write one sentence about what is making you tense right now, then one small thing within your control that you can do next. Seeing the worry on paper often makes it feel more manageable."),
                new WellnessResource("MOOD", "Ten-minute reset walk",
                        "A short walk outside, ideally without your phone, can lift low or irritable moods. Notice three things you can see, hear and feel while you walk."),
                new WellnessResource("MOOD", "Reach out to one person",
                        "Send a message or call someone you trust, even if it is only to say hello. Connection does not have to mean talking about problems."),
                new WellnessResource("SLEEP", "Steady wake-up time",
                        "Try to wake up at about the same time every day, including weekends. A regular wake time anchors your body clock and usually makes falling asleep easier."),
                new WellnessResource("SLEEP", "Screen-free wind-down",
                        "For 30 minutes before bed, put screens away and do something calm such as reading, stretching or listening to quiet music. Keep the bedroom cool, dark and quiet."),
                new WellnessResource("WORKLOAD", "Pick your top three",
                        "Write down everything on your mind, then circle the three things that matter most this week. Work on those first and give the rest a later day."),
                new WellnessResource("WORKLOAD", "Plan a real break",
                        "Schedule a short break in your day the same way you would schedule a class or meeting. Even 10 minutes away from your desk helps you return with more energy."),
                new WellnessResource("CONCENTRATION", "25-5 focus blocks",
                        "Work on one task for 25 minutes with notifications off, then rest for 5 minutes. After four rounds, take a longer break of 15-20 minutes."),
                new WellnessResource("CONCENTRATION", "Clear one distraction",
                        "Choose one distraction (a tab, an app, a noisy spot) and remove it before you start your next task. Small changes in your environment add up."),
                new WellnessResource("SUPPORT", "Talk to someone you trust",
                        "You do not have to handle a hard time on your own. Consider talking to a friend, family member, teacher or your college counselling cell. A qualified counsellor or doctor can offer support that this app cannot."),
                new WellnessResource("GENERAL", "Keep your routines going",
                        "Regular sleep, meals, movement and time with people you like all protect your well-being. Keep up what is working and check in again next week."),
                new WellnessResource("GENERAL", "Three good things",
                        "At the end of the day, write down three things that went reasonably well, however small. This simple habit helps you notice positives alongside the pressures."));
        resources.saveAll(list);
        log.info("Seeded {} wellness resources", list.size());
    }

    private void seedAdmin() {
        String email = props.admin().email();
        String password = props.admin().password();
        if (email.isBlank() || password.isBlank() || users.existsByEmailIgnoreCase(email)) {
            return;
        }
        User admin = new User();
        admin.setEmail(email.trim().toLowerCase());
        admin.setPasswordHash(encoder.encode(password));
        admin.setDisplayName("Administrator");
        admin.setRole(Role.ADMIN);
        users.save(admin);
        log.info("Created administrator account {}", admin.getEmail());
    }
}
