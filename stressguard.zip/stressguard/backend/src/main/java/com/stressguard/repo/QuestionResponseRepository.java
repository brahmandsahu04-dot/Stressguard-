package com.stressguard.repo;

import com.stressguard.domain.QuestionResponse;
import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface QuestionResponseRepository extends JpaRepository<QuestionResponse, UUID> {

    @Query("select r from QuestionResponse r join fetch r.question q "
            + "where r.assessment.id = :assessmentId order by q.position")
    List<QuestionResponse> findByAssessmentId(@Param("assessmentId") UUID assessmentId);
}
