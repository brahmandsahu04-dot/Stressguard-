package com.stressguard.domain;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.UUID;

/** Security-relevant event. Deliberately contains no questionnaire answers or other sensitive content. */
@Entity
@Table(name = "audit_events")
public class AuditEvent {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "event_id")
    private UUID id;

    @Column(name = "actor_id")
    private UUID actorId;

    @Column(name = "event_type", nullable = false, length = 50)
    private String eventType;

    @Column(name = "event_time", nullable = false)
    private Instant timestamp;

    protected AuditEvent() {}

    public AuditEvent(UUID actorId, String eventType) {
        this.actorId = actorId;
        this.eventType = eventType;
        this.timestamp = Instant.now();
    }

    public UUID getId() { return id; }
    public UUID getActorId() { return actorId; }
    public String getEventType() { return eventType; }
    public Instant getTimestamp() { return timestamp; }
}
