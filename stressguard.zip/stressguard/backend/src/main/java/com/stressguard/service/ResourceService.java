package com.stressguard.service;

import com.stressguard.domain.WellnessResource;
import com.stressguard.dto.Dtos.CategoryScore;
import com.stressguard.dto.Dtos.ResourceDto;
import com.stressguard.repo.WellnessResourceRepository;
import com.stressguard.scoring.StressBand;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Chooses reviewed, non-clinical wellness suggestions from the user's reported pattern. */
@Service
public class ResourceService {

    private final WellnessResourceRepository repository;

    public ResourceService(WellnessResourceRepository repository) {
        this.repository = repository;
    }

    @Transactional(readOnly = true)
    public List<ResourceDto> all() {
        return repository.findAllByOrderByCategoryAscTitleAsc().stream().map(this::toDto).toList();
    }

    @Transactional(readOnly = true)
    public List<ResourceDto> recommend(StressBand band, List<CategoryScore> categoryScores) {
        List<WellnessResource> picked = new ArrayList<>();
        if (band == StressBand.HIGH) {
            picked.addAll(repository.findByCategoryOrderByTitleAsc("SUPPORT"));
        }
        // The (up to) two categories where the user reported the most stress, if they are above 50 %.
        List<String> top = categoryScores.stream()
                .filter(c -> c.maxScore() > 0 && c.score() * 2 >= c.maxScore() && c.score() > 0)
                .sorted(Comparator.comparingDouble((CategoryScore c) -> c.score() / (double) c.maxScore()).reversed())
                .limit(2).map(CategoryScore::category).toList();
        for (String category : top) {
            picked.addAll(repository.findByCategoryOrderByTitleAsc(category).stream().limit(2).toList());
        }
        if (top.isEmpty() && band != StressBand.HIGH) {
            picked.addAll(repository.findByCategoryOrderByTitleAsc("GENERAL").stream().limit(2).toList());
        }
        return picked.stream().map(this::toDto).toList();
    }

    private ResourceDto toDto(WellnessResource r) {
        return new ResourceDto(r.getId(), r.getCategory(), r.getTitle(), r.getContent());
    }
}
