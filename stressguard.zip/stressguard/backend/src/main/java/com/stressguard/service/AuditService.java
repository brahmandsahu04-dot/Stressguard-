package com.stressguard.service;

import com.stressguard.domain.AuditEvent;
import com.stressguard.repo.AuditEventRepository;
import java.util.UUID;
import org.springframework.stereotype.Service;

@Service
public class AuditService {

    private final AuditEventRepository repository;

    public AuditService(AuditEventRepository repository) {
        this.repository = repository;
    }

    /** Records that something happened. Never pass questionnaire answers, passwords or tokens. */
    public void log(UUID actorId, String eventType) {
        repository.save(new AuditEvent(actorId, eventType));
    }
}
