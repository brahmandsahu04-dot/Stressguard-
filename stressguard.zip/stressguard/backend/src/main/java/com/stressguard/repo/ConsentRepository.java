package com.stressguard.repo;

import com.stressguard.domain.Consent;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConsentRepository extends JpaRepository<Consent, UUID> {
    Optional<Consent> findFirstByUserIdAndPurposeAndWithdrawnAtIsNull(UUID userId, String purpose);
    List<Consent> findByUserIdOrderByGrantedAtDesc(UUID userId);
    void deleteByUserId(UUID userId);
}
