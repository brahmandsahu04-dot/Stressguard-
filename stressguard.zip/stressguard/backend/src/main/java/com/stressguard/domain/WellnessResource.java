package com.stressguard.domain;

import jakarta.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "wellness_resources")
public class WellnessResource {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "resource_id")
    private UUID id;

    /** Question categories plus SUPPORT and GENERAL. */
    @Column(nullable = false, length = 30)
    private String category;

    @Column(nullable = false, length = 150)
    private String title;

    @Column(nullable = false, length = 1500)
    private String content;

    @Column(nullable = false, length = 10)
    private String locale = "en";

    protected WellnessResource() {}

    public WellnessResource(String category, String title, String content) {
        this.category = category;
        this.title = title;
        this.content = content;
    }

    public UUID getId() { return id; }
    public String getCategory() { return category; }
    public String getTitle() { return title; }
    public String getContent() { return content; }
    public String getLocale() { return locale; }
}
