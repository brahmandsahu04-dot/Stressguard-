package com.stressguard.repo;

import com.stressguard.domain.Notification;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NotificationRepository extends JpaRepository<Notification, UUID> {
    Optional<Notification> findFirstByUserIdAndType(UUID userId, String type);
    void deleteByUserId(UUID userId);
}
