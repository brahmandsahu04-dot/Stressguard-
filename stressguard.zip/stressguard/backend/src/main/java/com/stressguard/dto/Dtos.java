package com.stressguard.dto;

import jakarta.validation.constraints.*;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Request and response objects of the REST API. */
public final class Dtos {

    private Dtos() {}

    public static final String PASSWORD_PATTERN = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).+$";
    public static final String PASSWORD_MESSAGE =
            "Password must be 8-72 characters with upper-case, lower-case and a digit";

    // ---- authentication ----
    public record RegisterRequest(
            @NotBlank @Email @Size(max = 255) String email,
            @NotBlank @Size(min = 8, max = 72, message = PASSWORD_MESSAGE)
            @Pattern(regexp = PASSWORD_PATTERN, message = PASSWORD_MESSAGE) String password,
            @NotBlank @Size(max = 100) String displayName,
            Boolean consentAssessmentStorage) {}

    public record LoginRequest(@NotBlank String email, @NotBlank String password) {}

    public record ForgotPasswordRequest(@NotBlank @Email String email) {}

    public record ResetPasswordRequest(
            @NotBlank String token,
            @NotBlank @Size(min = 8, max = 72, message = PASSWORD_MESSAGE)
            @Pattern(regexp = PASSWORD_PATTERN, message = PASSWORD_MESSAGE) String newPassword) {}

    public record UserDto(UUID id, String email, String displayName, String role) {}

    public record AuthResponse(String token, UserDto user) {}

    // ---- questionnaire / assessment ----
    public record QuestionDto(UUID id, String text, String category) {}

    public record AssessmentRequest(
            @NotBlank String questionnaireVersion,
            @NotEmpty @Size(max = 40) List<@NotNull @Min(0) @Max(4) Integer> answers,
            @NotNull Boolean consentConfirmed,
            /** Optional safety check-in. It is used only for this response and is never stored. */
            Boolean safetyConcern) {}

    public record CategoryScore(String category, int score, int maxScore) {}

    public record ResourceDto(UUID id, String category, String title, String content) {}

    public record ContactDto(String name, String phone, String note) {}

    public record AssessmentResponse(
            UUID id, String questionnaireVersion, int totalScore, int maxScore, int percent,
            String band, String guidance, List<CategoryScore> categoryScores,
            List<ResourceDto> recommendations, List<ContactDto> supportContacts,
            boolean urgent, Instant completedAt, String disclaimer) {}

    public record AssessmentSummary(UUID id, int totalScore, int maxScore, int percent,
                                    String band, Instant completedAt) {}

    public record TrendResponse(int days, List<AssessmentSummary> points, Double averagePercent,
                                String direction, Integer changePercent) {}

    // ---- consent / reminders / privacy ----
    public record ConsentDto(String purpose, boolean active, String version,
                             Instant grantedAt, Instant withdrawnAt) {}

    public record ConsentUpdateRequest(@NotBlank String purpose, @NotNull Boolean granted) {}

    public record ReminderDto(boolean enabled, Instant nextDue, boolean due) {}

    public record ReminderRequest(@NotNull Boolean enabled) {}

    public record DeleteAccountRequest(@NotBlank String password) {}

    // ---- administration ----
    public record AdminQuestionRequest(
            @NotBlank @Size(max = 500) String text,
            @NotBlank String category,
            Boolean active) {}

    public record AdminQuestionDto(UUID id, String text, String category, boolean active,
                                   String version, int position) {}

    public record StatsDto(long totalUsers, long totalAssessments, long assessmentsLast7Days,
                           Map<String, Long> bandDistribution) {}

    // ---- errors ----
    public record ErrorResponse(String code, String message, Map<String, String> fields, Instant timestamp) {}
}
