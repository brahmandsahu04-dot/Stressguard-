package com.stressguard.config;

import java.util.List;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

@ConfigurationProperties(prefix = "stressguard")
public record AppProperties(
        @DefaultValue("v1") String questionnaireVersion,
        @DefaultValue("v1") String consentVersion,
        @DefaultValue Jwt jwt,
        @DefaultValue Cors cors,
        @DefaultValue Security security,
        @DefaultValue("false") boolean devLogResetToken,
        @DefaultValue Admin admin) {

    public record Jwt(@DefaultValue("") String secret, @DefaultValue("120") long expiryMinutes) {}

    public record Cors(@DefaultValue("http://localhost:5173") List<String> allowedOrigins) {}

    public record Security(@DefaultValue("5") int maxFailedAttempts, @DefaultValue("15") long lockMinutes) {}

    public record Admin(@DefaultValue("") String email, @DefaultValue("") String password) {}
}
