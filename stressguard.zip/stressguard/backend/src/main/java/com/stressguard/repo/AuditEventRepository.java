package com.stressguard.repo;

import com.stressguard.domain.AuditEvent;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuditEventRepository extends JpaRepository<AuditEvent, UUID> {
    long countByEventType(String eventType);
}
