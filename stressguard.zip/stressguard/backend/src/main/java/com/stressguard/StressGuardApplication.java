package com.stressguard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

@SpringBootApplication
@ConfigurationPropertiesScan
public class StressGuardApplication {
    public static void main(String[] args) {
        SpringApplication.run(StressGuardApplication.class, args);
    }
}
