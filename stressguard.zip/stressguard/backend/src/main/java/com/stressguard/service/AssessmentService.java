package com.stressguard.service;

import com.stressguard.config.AppProperties;
import com.stressguard.domain.*;
import com.stressguard.dto.Dtos.*;
import com.stressguard.repo.*;
import com.stressguard.scoring.AssessmentResult;
import com.stressguard.scoring.StressBand;
import com.stressguard.scoring.StressScoringService;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AssessmentService {

    static final String DISCLAIMER = "This score is a self-reported wellness indicator. It is not a medical "
            + "diagnosis and does not replace advice from a qualified professional.";

    /** Helplines in India. Check that they are right for your location before deployment. */
    static final List<ContactDto> SUPPORT_CONTACTS = List.of(
            new ContactDto("Tele-MANAS (Govt. of India, 24x7)", "14416", "Free tele-mental-health support"),
            new ContactDto("KIRAN Mental Health Helpline", "1800-599-0019", "Free, 24x7"),
            new ContactDto("Emergency services", "112", "If you or someone else is in immediate danger"));

    private final AssessmentRepository assessments;
    private final QuestionRepository questions;
    private final QuestionResponseRepository responses;
    private final UserRepository users;
    private final StressScoringService scoring;
    private final ConsentService consents;
    private final ResourceService resources;
    private final ReminderService reminders;
    private final AuditService audit;
    private final AppProperties props;

    public AssessmentService(AssessmentRepository assessments, QuestionRepository questions,
                             QuestionResponseRepository responses, UserRepository users,
                             StressScoringService scoring, ConsentService consents,
                             ResourceService resources, ReminderService reminders,
                             AuditService audit, AppProperties props) {
        this.assessments = assessments;
        this.questions = questions;
        this.responses = responses;
        this.users = users;
        this.scoring = scoring;
        this.consents = consents;
        this.resources = resources;
        this.reminders = reminders;
        this.audit = audit;
        this.props = props;
    }

    @Transactional(readOnly = true)
    public List<QuestionDto> activeQuestions() {
        return questions.findByVersionAndActiveTrueOrderByPositionAsc(props.questionnaireVersion()).stream()
                .map(q -> new QuestionDto(q.getId(), q.getText(), q.getCategory())).toList();
    }

    @Transactional
    public AssessmentResponse submit(UUID userId, AssessmentRequest req) {
        if (!Boolean.TRUE.equals(req.consentConfirmed())
                || !consents.isActive(userId, ConsentService.ASSESSMENT_STORAGE)) {
            throw new ApiException(HttpStatus.FORBIDDEN, "CONSENT_REQUIRED",
                    "Consent to store assessment responses is required before submitting");
        }
        if (!props.questionnaireVersion().equals(req.questionnaireVersion())) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "VERSION_MISMATCH",
                    "This questionnaire version is no longer active. Please reload the page.");
        }
        List<Question> active = questions.findByVersionAndActiveTrueOrderByPositionAsc(req.questionnaireVersion());
        if (active.size() != req.answers().size()) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "ANSWER_COUNT",
                    "Expected " + active.size() + " answers but received " + req.answers().size());
        }

        AssessmentResult result = scoring.calculate(req.answers());
        User user = users.getReferenceById(userId);
        Assessment assessment = assessments.save(new Assessment(user, req.questionnaireVersion(),
                result.totalScore(), result.maxScore(), result.band().name(), Instant.now()));

        List<QuestionResponse> saved = new ArrayList<>();
        for (int i = 0; i < active.size(); i++) {
            saved.add(new QuestionResponse(assessment, active.get(i), req.answers().get(i)));
        }
        responses.saveAll(saved);

        audit.log(userId, "ASSESSMENT_SUBMITTED"); // no scores or answers are logged
        reminders.rescheduleAfterCheckIn(userId);
        return build(assessment, saved, Boolean.TRUE.equals(req.safetyConcern()));
    }

    @Transactional(readOnly = true)
    public List<AssessmentSummary> history(UUID userId) {
        return assessments.findByUser_IdOrderByCompletedAtDesc(userId).stream().map(this::summary).toList();
    }

    @Transactional(readOnly = true)
    public AssessmentResponse get(UUID userId, UUID assessmentId) {
        Assessment a = assessments.findById(assessmentId)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "NOT_FOUND", "Assessment not found"));
        if (!a.getUser().getId().equals(userId)) {
            throw new ApiException(HttpStatus.FORBIDDEN, "FORBIDDEN", "Access denied");
        }
        return build(a, responses.findByAssessmentId(a.getId()), false);
    }

    @Transactional(readOnly = true)
    public TrendResponse trends(UUID userId, int days) {
        int window = Math.max(1, Math.min(days, 365));
        Instant since = Instant.now().minus(window, ChronoUnit.DAYS);
        List<AssessmentSummary> points = assessments
                .findByUser_IdAndCompletedAtAfterOrderByCompletedAtAsc(userId, since).stream()
                .map(this::summary).toList();
        if (points.isEmpty()) {
            return new TrendResponse(window, points, null, "INSUFFICIENT_DATA", null);
        }
        double avg = points.stream().mapToInt(AssessmentSummary::percent).average().orElse(0);
        if (points.size() < 2) {
            return new TrendResponse(window, points, round1(avg), "INSUFFICIENT_DATA", null);
        }
        // Latest result compared with the average of the earlier ones in the window.
        AssessmentSummary latest = points.get(points.size() - 1);
        double earlier = points.subList(0, points.size() - 1).stream()
                .mapToInt(AssessmentSummary::percent).average().orElse(latest.percent());
        int change = (int) Math.round(latest.percent() - earlier);
        String direction = change <= -5 ? "DECREASING" : change >= 5 ? "INCREASING" : "STABLE";
        return new TrendResponse(window, points, round1(avg), direction, change);
    }

    // ------------------------------------------------------------------

    private AssessmentResponse build(Assessment a, List<QuestionResponse> rs, boolean urgent) {
        Map<String, int[]> byCategory = new LinkedHashMap<>();
        for (QuestionResponse r : rs) {
            int[] totals = byCategory.computeIfAbsent(r.getQuestion().getCategory(), k -> new int[2]);
            totals[0] += r.getAnswerValue();
            totals[1] += StressScoringService.MAX_ANSWER;
        }
        List<CategoryScore> categoryScores = byCategory.entrySet().stream()
                .map(e -> new CategoryScore(e.getKey(), e.getValue()[0], e.getValue()[1])).toList();

        StressBand band = StressBand.valueOf(a.getSeverityBand());
        List<ContactDto> contacts = (band == StressBand.HIGH || urgent) ? SUPPORT_CONTACTS : List.of();
        return new AssessmentResponse(a.getId(), a.getQuestionnaireVersion(), a.getTotalScore(), a.getMaxScore(),
                percent(a), band.name(), scoring.guidanceFor(band), categoryScores,
                resources.recommend(band, categoryScores), contacts, urgent, a.getCompletedAt(), DISCLAIMER);
    }

    private AssessmentSummary summary(Assessment a) {
        return new AssessmentSummary(a.getId(), a.getTotalScore(), a.getMaxScore(), percent(a),
                a.getSeverityBand(), a.getCompletedAt());
    }

    private static int percent(Assessment a) {
        return a.getMaxScore() == 0 ? 0 : (int) Math.round(a.getTotalScore() * 100.0 / a.getMaxScore());
    }

    private static double round1(double v) {
        return Math.round(v * 10.0) / 10.0;
    }
}
