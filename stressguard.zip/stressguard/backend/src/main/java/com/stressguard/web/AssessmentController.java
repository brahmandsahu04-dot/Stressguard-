package com.stressguard.web;

import com.stressguard.dto.Dtos.*;
import com.stressguard.service.AssessmentService;
import jakarta.validation.Valid;
import java.util.List;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/assessments")
public class AssessmentController {

    private final AssessmentService service;

    public AssessmentController(AssessmentService service) {
        this.service = service;
    }

    @PostMapping
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<AssessmentResponse> submit(@Valid @RequestBody AssessmentRequest request,
                                                     Authentication authentication) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.submit(CurrentUser.id(authentication), request));
    }

    @GetMapping("/me")
    @PreAuthorize("isAuthenticated()")
    public List<AssessmentSummary> history(Authentication authentication) {
        return service.history(CurrentUser.id(authentication));
    }

    @GetMapping("/trends")
    @PreAuthorize("isAuthenticated()")
    public TrendResponse trends(@RequestParam(defaultValue = "30") int days, Authentication authentication) {
        return service.trends(CurrentUser.id(authentication), days);
    }

    @GetMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public AssessmentResponse get(@PathVariable UUID id, Authentication authentication) {
        return service.get(CurrentUser.id(authentication), id);
    }
}
