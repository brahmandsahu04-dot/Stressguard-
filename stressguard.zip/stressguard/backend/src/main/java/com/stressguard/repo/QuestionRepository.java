package com.stressguard.repo;

import com.stressguard.domain.Question;
import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface QuestionRepository extends JpaRepository<Question, UUID> {
    List<Question> findByVersionAndActiveTrueOrderByPositionAsc(String version);
    List<Question> findAllByOrderByPositionAsc();

    @Query("select coalesce(max(q.position), 0) from Question q")
    int maxPosition();
}
