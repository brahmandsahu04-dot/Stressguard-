package com.stressguard.web;

import java.util.UUID;
import org.springframework.security.core.Authentication;

/** The user id always comes from the authenticated principal, never from the request body. */
final class CurrentUser {
    private CurrentUser() {}

    static UUID id(Authentication authentication) {
        return UUID.fromString(authentication.getName());
    }
}
