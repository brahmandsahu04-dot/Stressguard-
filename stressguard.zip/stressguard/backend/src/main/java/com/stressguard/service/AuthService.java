package com.stressguard.service;

import com.stressguard.config.AppProperties;
import com.stressguard.domain.User;
import com.stressguard.dto.Dtos.*;
import com.stressguard.repo.UserRepository;
import com.stressguard.security.JwtService;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.HexFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthService {

    private static final Logger log = LoggerFactory.getLogger(AuthService.class);
    private static final SecureRandom RANDOM = new SecureRandom();

    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final JwtService jwt;
    private final ConsentService consents;
    private final AuditService audit;
    private final AppProperties props;
    /** Used to spend the same time on unknown e-mail addresses as on wrong passwords. */
    private final String dummyHash;

    public AuthService(UserRepository users, PasswordEncoder encoder, JwtService jwt,
                       ConsentService consents, AuditService audit, AppProperties props) {
        this.users = users;
        this.encoder = encoder;
        this.jwt = jwt;
        this.consents = consents;
        this.audit = audit;
        this.props = props;
        this.dummyHash = encoder.encode("stressguard-dummy-password");
    }

    @Transactional
    public AuthResponse register(RegisterRequest req) {
        String email = normalise(req.email());
        if (users.existsByEmailIgnoreCase(email)) {
            throw new ApiException(HttpStatus.CONFLICT, "EMAIL_TAKEN", "An account with this e-mail already exists");
        }
        User user = new User();
        user.setEmail(email);
        user.setPasswordHash(encoder.encode(req.password()));
        user.setDisplayName(req.displayName().trim());
        user = users.save(user);
        audit.log(user.getId(), "REGISTER");
        if (Boolean.TRUE.equals(req.consentAssessmentStorage())) {
            consents.update(user.getId(), ConsentService.ASSESSMENT_STORAGE, true);
        }
        return new AuthResponse(jwt.generate(user), toDto(user));
    }

    @Transactional(noRollbackFor = ApiException.class)
    public AuthResponse login(LoginRequest req) {
        User user = users.findByEmailIgnoreCase(normalise(req.email())).orElse(null);
        if (user == null) {
            encoder.matches(req.password(), dummyHash);
            throw badCredentials();
        }
        Instant now = Instant.now();
        if (user.getLockedUntil() != null && now.isBefore(user.getLockedUntil())) {
            audit.log(user.getId(), "LOGIN_BLOCKED");
            throw new ApiException(HttpStatus.TOO_MANY_REQUESTS, "ACCOUNT_LOCKED",
                    "Too many failed attempts. Please try again later.");
        }
        if (!encoder.matches(req.password(), user.getPasswordHash())) {
            int failed = user.getFailedAttempts() + 1;
            user.setFailedAttempts(failed);
            if (failed >= props.security().maxFailedAttempts()) {
                user.setLockedUntil(now.plus(props.security().lockMinutes(), ChronoUnit.MINUTES));
                user.setFailedAttempts(0);
            }
            users.save(user);
            audit.log(user.getId(), "LOGIN_FAILURE");
            throw badCredentials();
        }
        if (!"ACTIVE".equals(user.getAccountStatus())) {
            throw badCredentials();
        }
        user.setFailedAttempts(0);
        user.setLockedUntil(null);
        users.save(user);
        audit.log(user.getId(), "LOGIN_SUCCESS");
        return new AuthResponse(jwt.generate(user), toDto(user));
    }

    /** Always succeeds from the caller's point of view so that e-mail addresses cannot be probed. */
    @Transactional
    public void forgotPassword(String email) {
        users.findByEmailIgnoreCase(normalise(email)).ifPresent(user -> {
            byte[] raw = new byte[32];
            RANDOM.nextBytes(raw);
            String token = Base64.getUrlEncoder().withoutPadding().encodeToString(raw);
            user.setResetTokenHash(sha256(token));
            user.setResetTokenExpiry(Instant.now().plus(30, ChronoUnit.MINUTES));
            users.save(user);
            audit.log(user.getId(), "PASSWORD_RESET_REQUESTED");
            if (props.devLogResetToken()) {
                // Development convenience only: there is no mail server in this prototype.
                log.info("DEV ONLY - password reset token for {}: {}", user.getEmail(), token);
            }
        });
    }

    @Transactional
    public void resetPassword(ResetPasswordRequest req) {
        User user = users.findByResetTokenHash(sha256(req.token()))
                .filter(u -> u.getResetTokenExpiry() != null && Instant.now().isBefore(u.getResetTokenExpiry()))
                .orElseThrow(() -> new ApiException(HttpStatus.BAD_REQUEST, "INVALID_TOKEN",
                        "This reset link is invalid or has expired"));
        user.setPasswordHash(encoder.encode(req.newPassword()));
        user.setResetTokenHash(null);
        user.setResetTokenExpiry(null);
        user.setFailedAttempts(0);
        user.setLockedUntil(null);
        users.save(user);
        audit.log(user.getId(), "PASSWORD_RESET_DONE");
    }

    public static UserDto toDto(User u) {
        return new UserDto(u.getId(), u.getEmail(), u.getDisplayName(), u.getRole().name());
    }

    private static ApiException badCredentials() {
        return new ApiException(HttpStatus.UNAUTHORIZED, "BAD_CREDENTIALS", "Invalid email or password");
    }

    private static String normalise(String email) {
        return email.trim().toLowerCase();
    }

    private static String sha256(String value) {
        try {
            return HexFormat.of().formatHex(
                    MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
