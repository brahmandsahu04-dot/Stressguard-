package com.stressguard.service;

import com.stressguard.config.AppProperties;
import com.stressguard.domain.Question;
import com.stressguard.dto.Dtos.*;
import com.stressguard.repo.AssessmentRepository;
import com.stressguard.repo.QuestionRepository;
import com.stressguard.repo.UserRepository;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Administration (FR-11): questionnaire content and aggregate statistics only - never private answers. */
@Service
public class AdminService {

    public static final Set<String> CATEGORIES = Set.of("STRESS", "MOOD", "SLEEP", "WORKLOAD", "CONCENTRATION");

    private final QuestionRepository questions;
    private final UserRepository users;
    private final AssessmentRepository assessments;
    private final AppProperties props;
    private final AuditService audit;

    public AdminService(QuestionRepository questions, UserRepository users, AssessmentRepository assessments,
                        AppProperties props, AuditService audit) {
        this.questions = questions;
        this.users = users;
        this.assessments = assessments;
        this.props = props;
        this.audit = audit;
    }

    @Transactional(readOnly = true)
    public List<AdminQuestionDto> listQuestions() {
        return questions.findAllByOrderByPositionAsc().stream().map(this::toDto).toList();
    }

    @Transactional
    public AdminQuestionDto create(UUID adminId, AdminQuestionRequest req) {
        String category = checkCategory(req.category());
        Question q = new Question(req.text().trim(), category, props.questionnaireVersion(),
                questions.maxPosition() + 1);
        if (req.active() != null) q.setActive(req.active());
        audit.log(adminId, "ADMIN_QUESTION_CREATED");
        return toDto(questions.save(q));
    }

    @Transactional
    public AdminQuestionDto update(UUID adminId, UUID id, AdminQuestionRequest req) {
        Question q = questions.findById(id)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "NOT_FOUND", "Question not found"));
        q.setText(req.text().trim());
        q.setCategory(checkCategory(req.category()));
        if (req.active() != null) q.setActive(req.active());
        audit.log(adminId, "ADMIN_QUESTION_UPDATED");
        return toDto(q);
    }

    @Transactional(readOnly = true)
    public StatsDto stats() {
        Map<String, Long> bands = new LinkedHashMap<>();
        bands.put("LOW", 0L);
        bands.put("MODERATE", 0L);
        bands.put("HIGH", 0L);
        for (Object[] row : assessments.countByBand()) {
            bands.put((String) row[0], (Long) row[1]);
        }
        return new StatsDto(users.count(), assessments.count(),
                assessments.countByCompletedAtAfter(Instant.now().minus(7, ChronoUnit.DAYS)), bands);
    }

    private static String checkCategory(String category) {
        String c = category.trim().toUpperCase();
        if (!CATEGORIES.contains(c)) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "BAD_CATEGORY", "Category must be one of " + CATEGORIES);
        }
        return c;
    }

    private AdminQuestionDto toDto(Question q) {
        return new AdminQuestionDto(q.getId(), q.getText(), q.getCategory(), q.isActive(), q.getVersion(), q.getPosition());
    }
}
