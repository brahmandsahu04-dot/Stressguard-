package com.stressguard.service;

import com.stressguard.config.AppProperties;
import com.stressguard.domain.Consent;
import com.stressguard.dto.Dtos.ConsentDto;
import com.stressguard.repo.ConsentRepository;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ConsentService {

    public static final String ASSESSMENT_STORAGE = "ASSESSMENT_STORAGE";
    private static final List<String> PURPOSES = List.of(ASSESSMENT_STORAGE);

    private final ConsentRepository repository;
    private final AppProperties props;
    private final AuditService audit;

    public ConsentService(ConsentRepository repository, AppProperties props, AuditService audit) {
        this.repository = repository;
        this.props = props;
        this.audit = audit;
    }

    @Transactional(readOnly = true)
    public boolean isActive(UUID userId, String purpose) {
        return repository.findFirstByUserIdAndPurposeAndWithdrawnAtIsNull(userId, purpose).isPresent();
    }

    /** Current state of every consent purpose, including the history of the latest record. */
    @Transactional(readOnly = true)
    public List<ConsentDto> current(UUID userId) {
        List<Consent> history = repository.findByUserIdOrderByGrantedAtDesc(userId);
        return PURPOSES.stream().map(purpose -> {
            Consent latest = history.stream().filter(c -> c.getPurpose().equals(purpose)).findFirst().orElse(null);
            if (latest == null) {
                return new ConsentDto(purpose, false, props.consentVersion(), null, null);
            }
            return new ConsentDto(purpose, latest.getWithdrawnAt() == null, latest.getVersion(),
                    latest.getGrantedAt(), latest.getWithdrawnAt());
        }).toList();
    }

    @Transactional
    public List<ConsentDto> update(UUID userId, String purpose, boolean granted) {
        if (!PURPOSES.contains(purpose)) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "UNKNOWN_PURPOSE", "Unknown consent purpose");
        }
        var active = repository.findFirstByUserIdAndPurposeAndWithdrawnAtIsNull(userId, purpose);
        if (granted && active.isEmpty()) {
            repository.save(new Consent(userId, purpose, props.consentVersion()));
            audit.log(userId, "CONSENT_GRANTED");
        } else if (!granted && active.isPresent()) {
            active.get().setWithdrawnAt(Instant.now());
            audit.log(userId, "CONSENT_WITHDRAWN");
        }
        return current(userId);
    }
}
