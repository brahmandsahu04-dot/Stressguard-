package com.stressguard.domain;

public enum Role { USER, ADMIN }
