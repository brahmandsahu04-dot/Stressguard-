package com.stressguard.domain;

import jakarta.persistence.*;
import java.util.UUID;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Table(name = "responses")
public class QuestionResponse {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "response_id")
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "assessment_id", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Assessment assessment;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "question_id", nullable = false)
    private Question question;

    @Column(name = "answer_value", nullable = false)
    private int answerValue;

    protected QuestionResponse() {}

    public QuestionResponse(Assessment assessment, Question question, int answerValue) {
        this.assessment = assessment;
        this.question = question;
        this.answerValue = answerValue;
    }

    public UUID getId() { return id; }
    public Assessment getAssessment() { return assessment; }
    public Question getQuestion() { return question; }
    public int getAnswerValue() { return answerValue; }
}
