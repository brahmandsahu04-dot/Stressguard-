package com.stressguard.scoring;

public record AssessmentResult(int totalScore, int maxScore, StressBand band, String guidance) {}
