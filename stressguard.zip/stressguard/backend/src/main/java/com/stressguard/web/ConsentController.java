package com.stressguard.web;

import com.stressguard.dto.Dtos.ConsentDto;
import com.stressguard.dto.Dtos.ConsentUpdateRequest;
import com.stressguard.service.ConsentService;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/consents")
public class ConsentController {

    private final ConsentService service;

    public ConsentController(ConsentService service) {
        this.service = service;
    }

    @GetMapping
    @PreAuthorize("isAuthenticated()")
    public List<ConsentDto> current(Authentication authentication) {
        return service.current(CurrentUser.id(authentication));
    }

    @PutMapping
    @PreAuthorize("isAuthenticated()")
    public List<ConsentDto> update(@Valid @RequestBody ConsentUpdateRequest request, Authentication authentication) {
        return service.update(CurrentUser.id(authentication), request.purpose(), request.granted());
    }
}
