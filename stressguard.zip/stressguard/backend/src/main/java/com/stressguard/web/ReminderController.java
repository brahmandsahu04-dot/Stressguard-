package com.stressguard.web;

import com.stressguard.dto.Dtos.ReminderDto;
import com.stressguard.dto.Dtos.ReminderRequest;
import com.stressguard.service.ReminderService;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/reminders")
public class ReminderController {

    private final ReminderService service;

    public ReminderController(ReminderService service) {
        this.service = service;
    }

    @GetMapping
    @PreAuthorize("isAuthenticated()")
    public ReminderDto get(Authentication authentication) {
        return service.get(CurrentUser.id(authentication));
    }

    @PutMapping
    @PreAuthorize("isAuthenticated()")
    public ReminderDto set(@Valid @RequestBody ReminderRequest request, Authentication authentication) {
        return service.set(CurrentUser.id(authentication), request.enabled());
    }
}
