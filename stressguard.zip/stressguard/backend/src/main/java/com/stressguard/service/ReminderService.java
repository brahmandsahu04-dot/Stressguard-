package com.stressguard.service;

import com.stressguard.domain.Notification;
import com.stressguard.dto.Dtos.ReminderDto;
import com.stressguard.repo.AssessmentRepository;
import com.stressguard.repo.NotificationRepository;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Optional weekly in-app check-in reminder. It is OFF until the user switches it on. */
@Service
public class ReminderService {

    static final String TYPE = "WEEKLY_CHECKIN";
    private static final long INTERVAL_DAYS = 7;

    private final NotificationRepository repository;
    private final AssessmentRepository assessmentRepository;

    public ReminderService(NotificationRepository repository, AssessmentRepository assessmentRepository) {
        this.repository = repository;
        this.assessmentRepository = assessmentRepository;
    }

    @Transactional(readOnly = true)
    public ReminderDto get(UUID userId) {
        return repository.findFirstByUserIdAndType(userId, TYPE)
                .filter(n -> "ENABLED".equals(n.getStatus()))
                .map(n -> new ReminderDto(true, n.getScheduledAt(),
                        n.getScheduledAt() != null && !Instant.now().isBefore(n.getScheduledAt())))
                .orElse(new ReminderDto(false, null, false));
    }

    @Transactional
    public ReminderDto set(UUID userId, boolean enabled) {
        Notification n = repository.findFirstByUserIdAndType(userId, TYPE)
                .orElseGet(() -> new Notification(userId, TYPE, "DISABLED", null));
        if (enabled) {
            Instant base = assessmentRepository.findByUser_IdOrderByCompletedAtDesc(userId).stream()
                    .findFirst().map(a -> a.getCompletedAt()).orElse(Instant.now());
            n.setStatus("ENABLED");
            n.setScheduledAt(base.plus(INTERVAL_DAYS, ChronoUnit.DAYS));
        } else {
            n.setStatus("DISABLED");
            n.setScheduledAt(null);
        }
        repository.save(n);
        return get(userId);
    }

    /** Called after a check-in: pushes the next reminder one week ahead if reminders are on. */
    @Transactional
    public void rescheduleAfterCheckIn(UUID userId) {
        repository.findFirstByUserIdAndType(userId, TYPE)
                .filter(n -> "ENABLED".equals(n.getStatus()))
                .ifPresent(n -> {
                    n.setScheduledAt(Instant.now().plus(INTERVAL_DAYS, ChronoUnit.DAYS));
                    repository.save(n);
                });
    }
}
