package com.stressguard.repo;

import com.stressguard.domain.WellnessResource;
import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WellnessResourceRepository extends JpaRepository<WellnessResource, UUID> {
    List<WellnessResource> findByCategoryOrderByTitleAsc(String category);
    List<WellnessResource> findAllByOrderByCategoryAscTitleAsc();
}
