package com.stressguard.scoring;

public enum StressBand { LOW, MODERATE, HIGH }
