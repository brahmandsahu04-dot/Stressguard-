package com.stressguard.service;

import com.stressguard.domain.*;
import com.stressguard.repo.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Data export and account deletion (FR-10). */
@Service
public class PrivacyService {

    private final UserRepository users;
    private final AssessmentRepository assessments;
    private final QuestionResponseRepository responses;
    private final ConsentRepository consents;
    private final NotificationRepository notifications;
    private final PasswordEncoder encoder;
    private final AuditService audit;

    public PrivacyService(UserRepository users, AssessmentRepository assessments,
                          QuestionResponseRepository responses, ConsentRepository consents,
                          NotificationRepository notifications, PasswordEncoder encoder, AuditService audit) {
        this.users = users;
        this.assessments = assessments;
        this.responses = responses;
        this.consents = consents;
        this.notifications = notifications;
        this.encoder = encoder;
        this.audit = audit;
    }

    @Transactional
    public Map<String, Object> export(UUID userId) {
        User user = users.findById(userId).orElseThrow();
        Map<String, Object> out = new LinkedHashMap<>();
        Map<String, Object> profile = new LinkedHashMap<>();
        profile.put("email", user.getEmail());
        profile.put("displayName", user.getDisplayName());
        profile.put("createdAt", user.getCreatedAt());
        out.put("profile", profile);

        List<Map<String, Object>> consentList = new ArrayList<>();
        for (Consent c : consents.findByUserIdOrderByGrantedAtDesc(userId)) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("purpose", c.getPurpose());
            m.put("version", c.getVersion());
            m.put("grantedAt", c.getGrantedAt());
            m.put("withdrawnAt", c.getWithdrawnAt());
            consentList.add(m);
        }
        out.put("consents", consentList);

        List<Map<String, Object>> assessmentList = new ArrayList<>();
        for (Assessment a : assessments.findByUser_IdOrderByCompletedAtDesc(userId)) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("completedAt", a.getCompletedAt());
            m.put("questionnaireVersion", a.getQuestionnaireVersion());
            m.put("totalScore", a.getTotalScore());
            m.put("maxScore", a.getMaxScore());
            m.put("band", a.getSeverityBand());
            List<Map<String, Object>> answers = new ArrayList<>();
            for (QuestionResponse r : responses.findByAssessmentId(a.getId())) {
                Map<String, Object> ans = new LinkedHashMap<>();
                ans.put("question", r.getQuestion().getText());
                ans.put("category", r.getQuestion().getCategory());
                ans.put("answer", r.getAnswerValue());
                answers.add(ans);
            }
            m.put("answers", answers);
            assessmentList.add(m);
        }
        out.put("assessments", assessmentList);
        audit.log(userId, "DATA_EXPORTED");
        return out;
    }

    /**
     * Permanently deletes the account, its consents, reminders, assessments and answers.
     * Only a pseudonymous audit trail (random user id + event type) is kept.
     */
    @Transactional
    public void deleteAccount(UUID userId, String password) {
        User user = users.findById(userId).orElseThrow();
        if (!encoder.matches(password, user.getPasswordHash())) {
            throw new ApiException(HttpStatus.FORBIDDEN, "BAD_PASSWORD", "Password is incorrect");
        }
        consents.deleteByUserId(userId);
        notifications.deleteByUserId(userId);
        users.delete(user); // assessments and responses are removed by ON DELETE CASCADE
        users.flush();
        audit.log(userId, "ACCOUNT_DELETED");
    }
}
