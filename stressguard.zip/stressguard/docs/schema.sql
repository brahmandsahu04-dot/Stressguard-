-- StressGuard PostgreSQL schema (reference).
-- The Spring Boot application creates/updates these tables automatically (spring.jpa.hibernate.ddl-auto=update).
-- Use this file if you prefer to create the schema by hand, or to show the tables in your viva.

CREATE TABLE users (
    id                UUID PRIMARY KEY,
    email             VARCHAR(255) NOT NULL UNIQUE,
    password_hash     TEXT         NOT NULL,                 -- BCrypt hash, never plain text
    display_name      VARCHAR(100) NOT NULL,
    account_status    VARCHAR(20)  NOT NULL DEFAULT 'ACTIVE',-- ACTIVE | LOCKED | PENDING_VERIFICATION
    role              VARCHAR(20)  NOT NULL DEFAULT 'USER',  -- USER | ADMIN
    failed_attempts   INTEGER      NOT NULL DEFAULT 0,
    locked_until      TIMESTAMPTZ,
    reset_token_hash  VARCHAR(64),
    reset_token_expiry TIMESTAMPTZ,
    created_at        TIMESTAMPTZ  NOT NULL,
    updated_at        TIMESTAMPTZ  NOT NULL
);

CREATE TABLE questions (
    question_id UUID PRIMARY KEY,
    text        VARCHAR(500) NOT NULL,
    category    VARCHAR(30)  NOT NULL,   -- STRESS | MOOD | SLEEP | WORKLOAD | CONCENTRATION
    active      BOOLEAN      NOT NULL DEFAULT TRUE,
    version     VARCHAR(40)  NOT NULL,
    position    INTEGER      NOT NULL
);

CREATE TABLE assessments (
    assessment_id         UUID PRIMARY KEY,
    user_id               UUID        NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    questionnaire_version VARCHAR(40) NOT NULL,
    total_score           INTEGER     NOT NULL,
    max_score             INTEGER     NOT NULL,
    severity_band         VARCHAR(20) NOT NULL,   -- LOW | MODERATE | HIGH
    completed_at          TIMESTAMPTZ NOT NULL
);
CREATE INDEX idx_assessments_user_time ON assessments(user_id, completed_at);

CREATE TABLE responses (
    response_id   UUID PRIMARY KEY,
    assessment_id UUID    NOT NULL REFERENCES assessments(assessment_id) ON DELETE CASCADE,
    question_id   UUID    NOT NULL REFERENCES questions(question_id),
    answer_value  INTEGER NOT NULL CHECK (answer_value BETWEEN 0 AND 4)
);

CREATE TABLE consents (
    consent_id   UUID PRIMARY KEY,
    user_id      UUID        NOT NULL,
    purpose      VARCHAR(50) NOT NULL,
    version      VARCHAR(20) NOT NULL,
    granted_at   TIMESTAMPTZ NOT NULL,
    withdrawn_at TIMESTAMPTZ
);

CREATE TABLE notifications (
    notification_id UUID PRIMARY KEY,
    user_id         UUID        NOT NULL,
    type            VARCHAR(30) NOT NULL,
    status          VARCHAR(20) NOT NULL,   -- ENABLED | DISABLED
    scheduled_at    TIMESTAMPTZ
);

CREATE TABLE audit_events (
    event_id   UUID PRIMARY KEY,
    actor_id   UUID,
    event_type VARCHAR(50) NOT NULL,
    event_time TIMESTAMPTZ NOT NULL
);

CREATE TABLE wellness_resources (
    resource_id UUID PRIMARY KEY,
    category    VARCHAR(30)   NOT NULL,
    title       VARCHAR(150)  NOT NULL,
    content     VARCHAR(1500) NOT NULL,
    locale      VARCHAR(10)   NOT NULL DEFAULT 'en'
);
